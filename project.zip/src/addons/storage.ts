import AsyncStorage from '@react-native-async-storage/async-storage';
import { Addon } from './types';

const ADDONS_KEY = 'music-player:addons-v2';

export async function loadAddons(): Promise<Addon[]> {
  try {
    const raw = await AsyncStorage.getItem(ADDONS_KEY);
    const list = raw ? (JSON.parse(raw) as Addon[]) : [];
    return Array.isArray(list) ? list : [];
  } catch {
    return [];
  }
}

export async function saveAddons(addons: Addon[]): Promise<void> {
  try {
    await AsyncStorage.setItem(ADDONS_KEY, JSON.stringify(addons));
  } catch {
    /* sem persistência */
  }
}
