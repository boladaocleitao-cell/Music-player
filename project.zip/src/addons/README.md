# Addons (fontes extras)

O app funciona sozinho com YouTube (busca) + catálogo da home. Addons são **opcionais**:
receitas em JSON que dizem como chamar uma API `.json` e onde estão os campos.
Nenhum código de terceiros é executado. Cada usuário adiciona por sua conta e risco,
e é responsável por ter direito de usar o conteúdo da fonte.

Arquivos: `types.ts` (formato) · `engine.ts` (executa a receita) · `templates.ts` (modelos em branco) · `storage.ts` (salva no aparelho).
Faixas de addon têm `source: 'remote'` e tocam pelo `expo-audio` (aceitam segundo plano e tela de bloqueio).

## Formato
```json
{
  "name": "Minha fonte",
  "baseUrl": "https://api.exemplo.com",
  "search": { "url": "{baseUrl}/search?q={query}&limit={limit}", "listPath": "data.results" },
  "list":   { "url": "{baseUrl}/playlist.json" },
  "map": {
    "id": "id",
    "title": ["title", "name"],
    "artist": "artists[*].name",
    "audio": ["downloadUrl[quality=160kbps].url", "downloadUrl[-1].url"],
    "artwork": "image[-1].url",
    "duration": "duration"
  }
}
```
- `search` (usa `{query}`) e/ou `list` (lista fixa, filtrada localmente se o usuário digitar).
- Variáveis na URL/headers/body: `{baseUrl}` `{query}` `{page}` `{limit}`. `method` pode ser `POST` com `body` e `headers`.
- Caminhos: `a.b`, `a[0]`, `a[-1]` (último), `a[*].name` (todos), `a[chave=valor].x`; uma lista de caminhos = o primeiro que tiver valor.
- `map.title` e `map.audio` são obrigatórios. Links `http://` viram `https://`; `audioPrefix`/`artworkPrefix` completam links relativos; durações em ms são convertidas.

## Como estender
- Novo campo no mapeamento: `types.ts` (`AddonMap`) + `itemToTrack` em `engine.ts`.
- Novo tipo de fonte (algo que não seja receita JSON): crie uma função que devolva `Track[]` e chame-a em `search` no `store/appStore.ts`, como já é feito com `searchYouTube`.
- Modelos prontos: adicione em `templates.ts`.
