import { Addon, AddonMap } from './types';

// Mapeamento "genérico": tenta os nomes de campo mais comuns.
export const GENERIC_MAP: AddonMap = {
  id: ['id', '_id', 'uuid', 'trackId'],
  title: ['title', 'name', 'titulo', 'nome', 'track', 'trackName'],
  artist: ['artist', 'artist.name', 'artists[*].name', 'author', 'artista', 'autor', 'singer'],
  audio: ['url', 'uri', 'audio', 'audioUrl', 'audio_url', 'src', 'stream', 'streamUrl', 'link', 'file', 'mp3', 'preview', 'previewUrl'],
  artwork: ['artwork', 'image', 'cover', 'thumbnail', 'img', 'capa', 'picture'],
  duration: ['duration', 'length'],
};

/** Cria uma fonte "lista" para um link de .json (lista de músicas ou resposta de API). */
export function makeListAddon(url: string): Addon {
  const host = url.replace(/^https?:\/\//i, '').split(/[/?#]/)[0] || 'link';
  const id = 'json-' + (host.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || 'link');
  return { id, name: `Lista JSON (${host})`, baseUrl: url, list: { url: '{baseUrl}' }, map: GENERIC_MAP };
}

// Modelos em branco para começar. Nenhuma API de terceiros vem embutida:
// quem adiciona uma fonte é responsável por ela e por ter direito de usar o conteúdo.
export const TEMPLATES: Addon[] = [
  { id: 'lista-json', name: 'Lista JSON simples', baseUrl: 'https://', list: { url: '{baseUrl}' }, map: GENERIC_MAP },
  {
    id: 'minha-fonte',
    name: 'Minha fonte',
    baseUrl: 'https://',
    search: { url: '{baseUrl}/search?q={query}', listPath: 'results' },
    map: { title: 'title', artist: 'artist', audio: 'url', artwork: 'image' },
  },
];
