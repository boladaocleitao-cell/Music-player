// Um caminho dentro do JSON, ex.: "data.results", "artists.primary[*].name",
// "downloadUrl[-1].url", "downloadUrl[quality=160kbps].url".
// Se for uma lista de caminhos, usa o primeiro que tiver valor.
export type Path = string | string[];

export interface AddonRequest {
  /** Aceita {baseUrl}, {query} e {page}. Se começar com "/", é relativo ao baseUrl. */
  url: string;
  method?: 'GET' | 'POST';
  headers?: Record<string, string>;
  /** Corpo do POST (texto), aceita {query} e {page} */
  body?: string;
  /** Onde está a lista de músicas no JSON. Vazio = detecta sozinho */
  listPath?: string;
}

export interface AddonMap {
  id?: Path;
  title: Path;
  artist?: Path;
  audio: Path;
  artwork?: Path;
  duration?: Path;
}

export interface Addon {
  id: string;
  name: string;
  baseUrl?: string;
  /** Pede {query}: usado quando o usuário digita uma busca */
  search?: AddonRequest;
  /** Lista fixa (playlist/catálogo): carregada sem busca */
  list?: AddonRequest;
  map: AddonMap;
  /** Prefixo para links relativos (ex.: "https://cdn.exemplo.com/") */
  audioPrefix?: string;
  artworkPrefix?: string;
}
