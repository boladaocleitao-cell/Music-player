export type TrackSource = 'local' | 'remote';

export interface Track {
  id: string;
  title: string;
  artist: string;
  // string = URL remota ou caminho de arquivo; number = require() de asset embutido
  uri: string | number;
  source: TrackSource;
  artwork?: string;
  duration?: number; // segundos, quando a API informa
}
