export type TrackSource = 'local' | 'remote' | 'youtube';

export interface Track {
  id: string;
  title: string;
  artist: string;
  // string = URL remota ou caminho de arquivo; number = require() de asset embutido
  uri: string | number;
  source: TrackSource;
  artwork?: string;
  duration?: number; // segundos, quando a API informa
  videoId?: string; // source 'youtube': se faltar, é descoberto na hora de tocar (auto-busca)
}

export interface Album {
  id: string;
  name: string;
  artist: string;
  artwork?: string;
}
