import React from 'react';
import { ActivityIndicator, Pressable, StyleSheet, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { usePlayer } from '../hooks/usePlayer';
import { colors, spacing } from '../theme';

export function Controls() {
  const { isPlaying, isBuffering, queue, previous, toggle, next } = usePlayer();
  const disabled = queue.length === 0;

  return (
    <View style={styles.row}>
      <Pressable onPress={previous} disabled={disabled} hitSlop={12} style={styles.side}>
        <Ionicons name="play-skip-back" size={28} color={disabled ? colors.track : colors.text} />
      </Pressable>

      <Pressable onPress={toggle} disabled={disabled} style={[styles.main, disabled && styles.mainOff]}>
        {isBuffering && !isPlaying ? (
          <ActivityIndicator color={colors.background} />
        ) : (
          <Ionicons
            name={isPlaying ? 'pause' : 'play'}
            size={30}
            color={colors.background}
            style={isPlaying ? undefined : styles.playNudge}
          />
        )}
      </Pressable>

      <Pressable onPress={next} disabled={disabled} hitSlop={12} style={styles.side}>
        <Ionicons name="play-skip-forward" size={28} color={disabled ? colors.track : colors.text} />
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: spacing.xl },
  side: { padding: spacing.sm },
  main: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: colors.accent,
    alignItems: 'center',
    justifyContent: 'center',
  },
  mainOff: { opacity: 0.4 },
  playNudge: { marginLeft: 3 }, // o triângulo parece descentralizado sem isso
});
