import React, { useRef } from 'react';
import { Animated, Pressable, PressableProps, StyleProp, ViewStyle } from 'react-native';

// Botão que "afunda" ao toque, com mola (estilo Apple Music).
// style = layout do botão; inner = estilo do conteúdo (centralizar etc.)
export function Press({
  children,
  style,
  inner,
  scaleTo = 0.92,
  ...rest
}: PressableProps & {
  style?: StyleProp<ViewStyle>;
  inner?: StyleProp<ViewStyle>;
  scaleTo?: number;
  children?: React.ReactNode;
}) {
  const scale = useRef(new Animated.Value(1)).current;
  const to = (v: number) =>
    Animated.spring(scale, { toValue: v, useNativeDriver: true, speed: 40, bounciness: 8 }).start();
  return (
    <Pressable {...rest} style={style} onPressIn={() => to(scaleTo)} onPressOut={() => to(1)}>
      <Animated.View style={[{ transform: [{ scale }] }, inner]}>{children}</Animated.View>
    </Pressable>
  );
}
