import React, { useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { useAppStore } from '../store/appStore';
import { playerActions } from '../hooks/usePlayer';
import { TrackList } from './TrackList';
import { Press } from './Press';
import { colors, spacing, typography } from '../theme';

export function LibraryView({ bottomPad }: { bottomPad: number }) {
  const favorites = useAppStore((s) => s.favorites);
  const recents = useAppStore((s) => s.recents);
  const [mode, setMode] = useState<'favs' | 'recents'>('favs');
  const list = mode === 'favs' ? favorites : recents;

  return (
    <View style={styles.flex}>
      <Text style={styles.heading}>Biblioteca</Text>
      <View style={styles.seg}>
        {(['favs', 'recents'] as const).map((m) => (
          <Press key={m} onPress={() => setMode(m)} scaleTo={0.95} inner={[styles.segBtn, mode === m && styles.segActive]}>
            <Text style={[styles.segText, mode === m && styles.segTextActive]}>{m === 'favs' ? 'Favoritas' : 'Recentes'}</Text>
          </Press>
        ))}
      </View>
      <TrackList
        tracks={list}
        bottomPad={bottomPad}
        onSelect={(i) => void playerActions.setQueue(list, i)}
        empty={mode === 'favs' ? 'Toque no coração no player para favoritar.' : 'Nada tocado ainda.'}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  heading: { ...typography.hero, color: colors.text, paddingHorizontal: spacing.md, paddingTop: spacing.sm, paddingBottom: spacing.md },
  seg: { flexDirection: 'row', gap: spacing.sm, paddingHorizontal: spacing.md, marginBottom: spacing.sm },
  segBtn: { paddingVertical: 8, paddingHorizontal: 18, borderRadius: 20, backgroundColor: colors.surface },
  segActive: { backgroundColor: colors.accent },
  segText: { ...typography.body, color: colors.textMuted },
  segTextActive: { color: colors.onAccent, fontWeight: '700' },
});
