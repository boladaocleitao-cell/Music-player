import React from 'react';
import { FlatList, StyleSheet, Text } from 'react-native';
import { Track } from '../types/track';
import { usePlayer } from '../hooks/usePlayer';
import { TrackItem } from './TrackItem';
import { colors, spacing, typography } from '../theme';

interface Props {
  tracks: Track[];
  onSelect: (index: number) => void;
}

export function TrackList({ tracks, onSelect }: Props) {
  const { track: current, isPlaying } = usePlayer();

  return (
    <FlatList
      data={tracks}
      keyExtractor={(t) => t.id}
      contentContainerStyle={styles.content}
      keyboardShouldPersistTaps="handled"
      renderItem={({ item, index }) => (
        <TrackItem
          track={item}
          active={current?.id === item.id}
          playing={isPlaying}
          onPress={() => onSelect(index)}
        />
      )}
      ListEmptyComponent={<Text style={styles.empty}>Nenhuma música. Faça uma busca.</Text>}
    />
  );
}

const styles = StyleSheet.create({
  content: { paddingHorizontal: spacing.sm, paddingBottom: spacing.md },
  empty: { ...typography.body, color: colors.textMuted, textAlign: 'center', marginTop: spacing.xl },
});
