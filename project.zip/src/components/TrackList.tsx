import React from 'react';
import { FlatList, StyleSheet, Text } from 'react-native';
import { Track } from '../types/track';
import { usePlayer } from '../hooks/usePlayer';
import { TrackItem } from './TrackItem';
import { colors, spacing, typography } from '../theme';

interface Props {
  tracks: Track[];
  onSelect: (index: number) => void;
  header?: React.ReactElement | null;
  empty?: string;
  refreshing?: boolean;
  onRefresh?: () => void;
  rank?: boolean;
  /** espaço no fim para não ficar atrás da barra e do player flutuantes */
  bottomPad?: number;
}

export function TrackList({ tracks, onSelect, header, empty, refreshing, onRefresh, rank, bottomPad = 0 }: Props) {
  const { track: current, isPlaying } = usePlayer();

  return (
    <FlatList
      data={tracks}
      keyExtractor={(t) => t.id}
      contentContainerStyle={{ paddingHorizontal: spacing.sm, paddingBottom: bottomPad }}
      keyboardShouldPersistTaps="handled"
      keyboardDismissMode="on-drag"
      renderItem={({ item, index }) => (
        <TrackItem
          track={item}
          index={index}
          rank={rank}
          active={current?.id === item.id}
          playing={isPlaying}
          onPress={() => onSelect(index)}
        />
      )}
      ListHeaderComponent={header}
      refreshing={refreshing}
      onRefresh={onRefresh}
      ListEmptyComponent={<Text style={styles.empty}>{empty ?? 'Nenhuma música.'}</Text>}
    />
  );
}

const styles = StyleSheet.create({
  empty: { ...typography.body, color: colors.textMuted, textAlign: 'center', marginTop: spacing.xl },
});
