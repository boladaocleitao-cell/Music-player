import React from 'react';
import { FlatList, StyleSheet, Text } from 'react-native';
import { Track } from '../types/track';
import { usePlayer } from '../hooks/usePlayer';
import { TrackItem } from './TrackItem';
import { colors, spacing, typography } from '../theme';

interface Props {
  tracks: Track[];
  onSelect: (index: number) => void;
  header?: React.ReactElement | null;
  empty?: string;
  refreshing?: boolean;
  onRefresh?: () => void;
}

export function TrackList({ tracks, onSelect, header, empty, refreshing, onRefresh }: Props) {
  const { track: current, isPlaying } = usePlayer();

  return (
    <FlatList
      data={tracks}
      keyExtractor={(t) => t.id}
      contentContainerStyle={styles.content}
      keyboardShouldPersistTaps="handled"
      renderItem={({ item, index }) => (
        <TrackItem
          track={item}
          active={current?.id === item.id}
          playing={isPlaying}
          onPress={() => onSelect(index)}
        />
      )}
      ListHeaderComponent={header}
      refreshing={refreshing}
      onRefresh={onRefresh}
      ListEmptyComponent={<Text style={styles.empty}>{empty ?? 'Nenhuma música.'}</Text>}
    />
  );
}

const styles = StyleSheet.create({
  content: { paddingHorizontal: spacing.sm, paddingBottom: spacing.md },
  empty: { ...typography.body, color: colors.textMuted, textAlign: 'center', marginTop: spacing.xl },
});
