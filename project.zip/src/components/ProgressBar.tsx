import React, { useRef, useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import Slider from '@react-native-community/slider';
import { useProgress } from '../hooks/useProgress';
import { playerActions } from '../hooks/usePlayer';
import { colors, typography } from '../theme';
import { formatTime } from '../utils/format';

export function ProgressBar() {
  const { position, duration } = useProgress();
  const [dragValue, setDragValue] = useState<number | null>(null);
  const isDragging = useRef(false);

  const shown = dragValue ?? position;
  const max = duration > 0 ? duration : 1;

  return (
    <View>
      <Slider
        value={shown}
        minimumValue={0}
        maximumValue={max}
        disabled={duration <= 0}
        minimumTrackTintColor={colors.accent}
        maximumTrackTintColor={colors.track}
        thumbTintColor={colors.accent}
        onSlidingStart={() => {
          isDragging.current = true;
        }}
        onValueChange={(v) => {
          if (isDragging.current) setDragValue(v);
        }}
        onSlidingComplete={async (v) => {
          isDragging.current = false;
          await playerActions.seekTo(v);
          setDragValue(null);
        }}
      />
      <View style={styles.times}>
        <Text style={styles.time}>{formatTime(shown)}</Text>
        <Text style={styles.time}>{formatTime(duration)}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  times: { flexDirection: 'row', justifyContent: 'space-between', paddingHorizontal: 4 },
  time: { ...typography.caption, color: colors.textMuted },
});
