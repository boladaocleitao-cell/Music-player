import React, { useState } from 'react';
import { ActivityIndicator, FlatList, Image, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useAppStore } from '../store/appStore';
import { playerActions } from '../hooks/usePlayer';
import { fetchAlbumTracks } from '../services/catalog';
import { TrackList } from './TrackList';
import { Press } from './Press';
import { Album, Track } from '../types/track';
import { colors, spacing, typography } from '../theme';

export function HomeView({ bottomPad, onSettings }: { bottomPad: number; onSettings: () => void }) {
  const songs = useAppStore((s) => s.homeSongs);
  const albums = useAppStore((s) => s.homeAlbums);
  const loading = useAppStore((s) => s.homeLoading);
  const error = useAppStore((s) => s.homeError);
  const loadHome = useAppStore((s) => s.loadHome);

  const [album, setAlbum] = useState<Album | null>(null);
  if (album) return <AlbumView album={album} onBack={() => setAlbum(null)} bottomPad={bottomPad} />;

  const featured = albums[0];
  const rest = albums.slice(1);

  const header = (
    <View>
      <View style={styles.top}>
        <Text style={styles.brand}>CloudGlass</Text>
        <Press onPress={onSettings} hitSlop={10} inner={styles.gear}>
          <Ionicons name="settings-outline" size={20} color={colors.text} />
        </Press>
      </View>
      {error && <Text style={styles.error}>{error}</Text>}

      {featured && (
        <Press onPress={() => setAlbum(featured)} scaleTo={0.97} style={styles.heroWrap} inner={styles.hero}>
          {featured.artwork ? <Image source={{ uri: featured.artwork }} style={StyleSheet.absoluteFill} /> : null}
          <LinearGradient colors={['rgba(13,8,24,0)', 'rgba(13,8,24,0.92)']} style={StyleSheet.absoluteFill} />
          <Text style={styles.heroKicker}>ÁLBUM EM DESTAQUE</Text>
          <Text style={styles.heroTitle} numberOfLines={2}>{featured.name}</Text>
          <Text style={styles.heroArtist} numberOfLines={1}>{featured.artist}</Text>
        </Press>
      )}

      {rest.length > 0 && (
        <>
          <Text style={styles.section}>Álbuns populares</Text>
          <FlatList
            data={rest}
            horizontal
            showsHorizontalScrollIndicator={false}
            keyExtractor={(a) => a.id}
            contentContainerStyle={styles.albumRow}
            renderItem={({ item }) => (
              <Press onPress={() => setAlbum(item)} scaleTo={0.95} style={styles.album}>
                {item.artwork ? (
                  <Image source={{ uri: item.artwork }} style={styles.cover} />
                ) : (
                  <View style={[styles.cover, styles.coverEmpty]} />
                )}
                <Text style={styles.albumName} numberOfLines={1}>{item.name}</Text>
                <Text style={styles.albumArtist} numberOfLines={1}>{item.artist}</Text>
              </Press>
            )}
          />
        </>
      )}
      {songs.length > 0 && <Text style={styles.section}>Músicas em destaque</Text>}
    </View>
  );

  return (
    <TrackList
      tracks={songs}
      rank
      bottomPad={bottomPad}
      onSelect={(i) => void playerActions.setQueue(songs, i)}
      header={header}
      empty={loading ? 'Carregando…' : 'Nada por aqui ainda.'}
      refreshing={loading}
      onRefresh={() => void loadHome()}
    />
  );
}

function AlbumView({ album, onBack, bottomPad }: { album: Album; onBack: () => void; bottomPad: number }) {
  const [tracks, setTracks] = useState<Track[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  React.useEffect(() => {
    let cancelled = false;
    fetchAlbumTracks(album)
      .then((t) => {
        if (cancelled) return;
        if (t.length === 0) setError('Não encontrei as faixas deste álbum.');
        setTracks(t);
      })
      .catch((e) => !cancelled && setError(e instanceof Error ? e.message : 'Erro ao carregar o álbum'));
    return () => {
      cancelled = true;
    };
  }, [album]);

  const header = (
    <View style={styles.albumHeader}>
      <Press onPress={onBack} hitSlop={10} style={styles.backWrap} inner={styles.back}>
        <Ionicons name="chevron-back" size={22} color={colors.text} />
        <Text style={styles.backText}>Início</Text>
      </Press>
      <View style={styles.albumTop}>
        {album.artwork ? (
          <Image source={{ uri: album.artwork }} style={styles.coverBig} />
        ) : (
          <View style={[styles.coverBig, styles.coverEmpty]} />
        )}
        <Text style={styles.albumTitle} numberOfLines={2}>{album.name}</Text>
        <Text style={styles.albumArtistBig}>{album.artist}</Text>
        {tracks && tracks.length > 0 && (
          <Press
            onPress={() => void playerActions.setQueue(tracks, 0)}
            scaleTo={0.94}
            inner={styles.playAll}
          >
            <Ionicons name="play" size={18} color={colors.onAccent} />
            <Text style={styles.playAllText}>Tocar</Text>
          </Press>
        )}
      </View>
      {error && <Text style={styles.error}>{error}</Text>}
      {!tracks && !error && <ActivityIndicator color={colors.textMuted} style={styles.spinner} />}
    </View>
  );

  return (
    <TrackList
      tracks={tracks ?? []}
      rank
      bottomPad={bottomPad}
      onSelect={(i) => void playerActions.setQueue(tracks ?? [], i)}
      header={header}
      empty=" "
    />
  );
}

const styles = StyleSheet.create({
  top: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: spacing.md, paddingTop: spacing.sm, paddingBottom: spacing.md },
  brand: { ...typography.hero, color: colors.text },
  gear: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(255,255,255,0.12)' },
  section: { ...typography.title, color: colors.text, paddingHorizontal: spacing.md, marginTop: spacing.lg, marginBottom: spacing.sm },
  error: { ...typography.caption, color: colors.danger, padding: spacing.md },
  heroWrap: { marginHorizontal: spacing.md },
  hero: { height: 300, borderRadius: 24, overflow: 'hidden', justifyContent: 'flex-end', padding: spacing.md, backgroundColor: colors.surfaceActive },
  heroKicker: { ...typography.caption, color: colors.accent, fontWeight: '800', letterSpacing: 1 },
  heroTitle: { fontSize: 28, fontWeight: '800', color: colors.text, marginTop: 4 },
  heroArtist: { ...typography.title, color: colors.textMuted, fontWeight: '500' },
  albumRow: { paddingHorizontal: spacing.md, gap: spacing.md },
  album: { width: 150 },
  cover: { width: 150, height: 150, borderRadius: 16, backgroundColor: colors.surface },
  coverEmpty: { backgroundColor: colors.surfaceActive },
  albumName: { ...typography.body, color: colors.text, marginTop: spacing.sm, fontWeight: '600' },
  albumArtist: { ...typography.caption, color: colors.textMuted, marginTop: 2 },
  albumHeader: { paddingBottom: spacing.sm },
  backWrap: { alignSelf: 'flex-start' },
  back: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: spacing.sm, paddingVertical: spacing.sm },
  backText: { ...typography.body, color: colors.text },
  albumTop: { alignItems: 'center', gap: 4, paddingHorizontal: spacing.md },
  coverBig: { width: 220, height: 220, borderRadius: 20, backgroundColor: colors.surface, marginBottom: spacing.sm },
  albumTitle: { fontSize: 22, fontWeight: '800', color: colors.text, textAlign: 'center' },
  albumArtistBig: { ...typography.title, color: colors.accent, fontWeight: '500' },
  playAll: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: colors.accent, borderRadius: 24, paddingHorizontal: 28, height: 46, marginTop: spacing.sm },
  playAllText: { ...typography.body, color: colors.onAccent, fontWeight: '700' },
  spinner: { marginTop: spacing.md },
});
