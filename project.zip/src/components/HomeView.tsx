import React, { useState } from 'react';
import { ActivityIndicator, FlatList, Image, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAppStore } from '../store/appStore';
import { playerActions } from '../hooks/usePlayer';
import { fetchAlbumTracks } from '../services/catalog';
import { TrackList } from './TrackList';
import { Album, Track } from '../types/track';
import { colors, spacing, typography } from '../theme';

export function HomeView() {
  const songs = useAppStore((s) => s.homeSongs);
  const albums = useAppStore((s) => s.homeAlbums);
  const loading = useAppStore((s) => s.homeLoading);
  const error = useAppStore((s) => s.homeError);
  const loadHome = useAppStore((s) => s.loadHome);

  const [album, setAlbum] = useState<Album | null>(null);

  if (album) return <AlbumView album={album} onBack={() => setAlbum(null)} />;

  const header = (
    <View>
      {error && <Text style={styles.error}>{error}</Text>}
      {albums.length > 0 && (
        <>
          <Text style={styles.section}>Álbuns</Text>
          <FlatList
            data={albums}
            horizontal
            showsHorizontalScrollIndicator={false}
            keyExtractor={(a) => a.id}
            contentContainerStyle={styles.albumRow}
            renderItem={({ item }) => (
              <Pressable style={styles.album} onPress={() => setAlbum(item)}>
                {item.artwork ? (
                  <Image source={{ uri: item.artwork }} style={styles.cover} />
                ) : (
                  <View style={[styles.cover, styles.coverEmpty]} />
                )}
                <Text style={styles.albumName} numberOfLines={1}>
                  {item.name}
                </Text>
                <Text style={styles.albumArtist} numberOfLines={1}>
                  {item.artist}
                </Text>
              </Pressable>
            )}
          />
        </>
      )}
      {songs.length > 0 && <Text style={styles.section}>Músicas</Text>}
    </View>
  );

  return (
    <TrackList
      tracks={songs}
      onSelect={(i) => void playerActions.setQueue(songs, i)}
      header={header}
      empty={loading ? 'Carregando…' : 'Nada por aqui ainda.'}
      refreshing={loading}
      onRefresh={() => void loadHome()}
    />
  );
}

function AlbumView({ album, onBack }: { album: Album; onBack: () => void }) {
  const [tracks, setTracks] = useState<Track[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  React.useEffect(() => {
    let cancelled = false;
    fetchAlbumTracks(album)
      .then((t) => {
        if (cancelled) return;
        if (t.length === 0) setError('Não encontrei as faixas deste álbum.');
        setTracks(t);
      })
      .catch((e) => !cancelled && setError(e instanceof Error ? e.message : 'Erro ao carregar o álbum'));
    return () => {
      cancelled = true;
    };
  }, [album]);

  const header = (
    <View style={styles.albumHeader}>
      <Pressable onPress={onBack} hitSlop={10} style={styles.back}>
        <Ionicons name="chevron-back" size={22} color={colors.text} />
        <Text style={styles.backText}>Home</Text>
      </Pressable>
      <View style={styles.albumTop}>
        {album.artwork ? (
          <Image source={{ uri: album.artwork }} style={styles.coverBig} />
        ) : (
          <View style={[styles.coverBig, styles.coverEmpty]} />
        )}
        <View style={styles.flex}>
          <Text style={styles.albumTitle} numberOfLines={3}>
            {album.name}
          </Text>
          <Text style={styles.albumArtist}>{album.artist}</Text>
        </View>
      </View>
      {error && <Text style={styles.error}>{error}</Text>}
      {!tracks && !error && <ActivityIndicator color={colors.textMuted} style={styles.spinner} />}
    </View>
  );

  return (
    <TrackList
      tracks={tracks ?? []}
      onSelect={(i) => void playerActions.setQueue(tracks ?? [], i)}
      header={header}
      empty=" "
    />
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  section: { ...typography.title, color: colors.text, paddingHorizontal: spacing.md, marginTop: spacing.md, marginBottom: spacing.sm },
  error: { ...typography.caption, color: '#E5484D', padding: spacing.md },
  albumRow: { paddingHorizontal: spacing.md, gap: spacing.md },
  album: { width: 128 },
  cover: { width: 128, height: 128, borderRadius: 10, backgroundColor: colors.surface },
  coverEmpty: { backgroundColor: colors.surfaceActive },
  albumName: { ...typography.body, color: colors.text, marginTop: spacing.xs },
  albumArtist: { ...typography.caption, color: colors.textMuted },
  albumHeader: { paddingBottom: spacing.sm },
  back: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: spacing.sm, paddingVertical: spacing.sm },
  backText: { ...typography.body, color: colors.text },
  albumTop: { flexDirection: 'row', gap: spacing.md, paddingHorizontal: spacing.md, alignItems: 'center' },
  coverBig: { width: 110, height: 110, borderRadius: 10, backgroundColor: colors.surface },
  albumTitle: { ...typography.title, color: colors.text },
  spinner: { marginTop: spacing.md },
});
