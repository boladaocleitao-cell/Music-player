import React, { memo, useEffect, useRef } from 'react';
import { Animated, Image, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Track } from '../types/track';
import { Press } from './Press';
import { colors, spacing, typography } from '../theme';
import { formatTime } from '../utils/format';

interface Props {
  track: Track;
  index: number;
  active: boolean;
  playing: boolean;
  rank?: boolean;
  onPress: () => void;
}

function TrackItemBase({ track, index, active, playing, rank, onPress }: Props) {
  // entrada em cascata: sobe e aparece, com atraso por posição
  const enter = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.timing(enter, { toValue: 1, duration: 380, delay: Math.min(index, 10) * 45, useNativeDriver: true }).start();
  }, [enter, index]);

  return (
    <Animated.View
      style={{
        opacity: enter,
        transform: [{ translateY: enter.interpolate({ inputRange: [0, 1], outputRange: [14, 0] }) }],
      }}
    >
      <Press onPress={onPress} scaleTo={0.97} inner={[styles.row, active && styles.rowActive]}>
        {rank && <Text style={styles.rank}>{index + 1}</Text>}
        {track.artwork ? (
          <Image source={{ uri: track.artwork }} style={styles.art} />
        ) : (
          <View style={[styles.art, styles.artEmpty]}>
            <Ionicons name="musical-notes" size={20} color={colors.textMuted} />
          </View>
        )}
        <View style={styles.info}>
          <Text style={[styles.title, active && styles.titleActive]} numberOfLines={1}>
            {track.title}
          </Text>
          <Text style={styles.artist} numberOfLines={1}>
            {track.artist}
            {track.duration ? `  ·  ${formatTime(track.duration)}` : ''}
          </Text>
        </View>
        {active ? (
          <Ionicons name={playing ? 'volume-high' : 'volume-low'} size={18} color={colors.accent} />
        ) : (
          <Ionicons name="play-circle-outline" size={24} color={colors.textMuted} />
        )}
      </Press>
    </Animated.View>
  );
}

export const TrackItem = memo(TrackItemBase);

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
    borderRadius: 16,
  },
  rowActive: { backgroundColor: colors.surfaceActive },
  rank: { width: 22, textAlign: 'center', ...typography.body, color: colors.textMuted, fontWeight: '600' },
  art: { width: 54, height: 54, borderRadius: 10, backgroundColor: colors.surface },
  artEmpty: { alignItems: 'center', justifyContent: 'center' },
  info: { flex: 1 },
  title: { ...typography.body, color: colors.text, fontWeight: '500' },
  titleActive: { color: colors.accent, fontWeight: '700' },
  artist: { ...typography.caption, color: colors.textMuted, marginTop: 3 },
});
