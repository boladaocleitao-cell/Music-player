import React, { memo } from 'react';
import { Image, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Track } from '../types/track';
import { colors, spacing, typography } from '../theme';

interface Props {
  track: Track;
  active: boolean;
  playing: boolean;
  onPress: () => void;
}

function TrackItemBase({ track, active, playing, onPress }: Props) {
  return (
    <Pressable onPress={onPress} style={[styles.row, active && styles.rowActive]}>
      {track.artwork ? (
        <Image source={{ uri: track.artwork }} style={styles.art} />
      ) : (
        <View style={[styles.art, styles.artEmpty]} />
      )}
      <View style={styles.info}>
        <Text style={[styles.title, active && styles.titleActive]} numberOfLines={1}>
          {track.title}
        </Text>
        <Text style={styles.artist} numberOfLines={1}>
          {track.artist}
        </Text>
      </View>
      {active && <Ionicons name={playing ? 'volume-high' : 'volume-low'} size={18} color={colors.accent} />}
    </Pressable>
  );
}

export const TrackItem = memo(TrackItemBase);

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
    borderRadius: 10,
  },
  rowActive: { backgroundColor: colors.surfaceActive },
  art: { width: 48, height: 48, borderRadius: 6, backgroundColor: colors.surface },
  artEmpty: { backgroundColor: colors.surfaceActive },
  info: { flex: 1 },
  title: { ...typography.body, color: colors.text },
  titleActive: { fontWeight: '600' },
  artist: { ...typography.caption, color: colors.textMuted, marginTop: 2 },
});
