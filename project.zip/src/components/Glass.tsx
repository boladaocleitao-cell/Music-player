import React from 'react';
import { StyleProp, StyleSheet, View, ViewStyle } from 'react-native';
import { BlurView } from 'expo-blur';
import { colors } from '../theme';

// "Liquid glass": desfoque do fundo + véu translúcido + borda de luz.
export function Glass({
  children,
  style,
  intensity = 45,
  radius = 28,
}: {
  children?: React.ReactNode;
  style?: StyleProp<ViewStyle>;
  intensity?: number;
  radius?: number;
}) {
  return (
    <View style={[styles.wrap, { borderRadius: radius }, style]}>
      <BlurView intensity={intensity} tint="dark" style={StyleSheet.absoluteFill} />
      <View style={[StyleSheet.absoluteFill, styles.veil]} />
      <View style={[StyleSheet.absoluteFill, styles.shine, { borderRadius: radius }]} pointerEvents="none" />
      {children}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { overflow: 'hidden', borderWidth: StyleSheet.hairlineWidth * 2, borderColor: colors.glassBorder },
  veil: { backgroundColor: colors.glassFill },
  // faixa de luz no topo, como o reflexo do vidro
  shine: { borderTopWidth: 1.5, borderTopColor: 'rgba(255,255,255,0.28)' },
});
