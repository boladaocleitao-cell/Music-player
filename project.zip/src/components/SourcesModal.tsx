import React, { useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAppStore } from '../store/appStore';
import { BLANK_ADDON, PRESETS } from '../data/presets';
import { Addon } from '../types/addon';
import { parseAddon, runAddon } from '../services/addonEngine';
import { colors, spacing, typography } from '../theme';

interface Props {
  visible: boolean;
  onClose: () => void;
}

type Message = { kind: 'ok' | 'error' | 'info'; text: string; sample?: string };

const MONO = Platform.select({ ios: 'Menlo', default: 'monospace' });

export function SourcesModal({ visible, onClose }: Props) {
  const addons = useAppStore((s) => s.addons);
  const activeId = useAppStore((s) => s.activeId);
  const setActive = useAppStore((s) => s.setActive);
  const saveAddon = useAppStore((s) => s.saveAddon);
  const removeAddon = useAppStore((s) => s.removeAddon);

  const [draft, setDraft] = useState<string | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [importUrl, setImportUrl] = useState('');
  const [testQuery, setTestQuery] = useState('believer');
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<Message | null>(null);

  // Campo rápido de baseUrl: lê e grava dentro do JSON do editor.
  // null = o JSON está inválido no momento (o campo fica desabilitado).
  const normalizeQuotes = (s: string) => s.replace(/[“”]/g, '"').replace(/[‘’]/g, "'");
  const draftBaseUrl: string | null = (() => {
    if (draft === null) return null;
    try {
      const o = JSON.parse(normalizeQuotes(draft)) as Record<string, unknown>;
      return typeof o.baseUrl === 'string' ? o.baseUrl : '';
    } catch {
      return null;
    }
  })();
  const setDraftBaseUrl = (value: string) => {
    if (draft === null) return;
    try {
      const o = JSON.parse(normalizeQuotes(draft)) as Record<string, unknown>;
      o.baseUrl = value;
      setDraft(JSON.stringify(o, null, 2));
    } catch {
      // JSON inválido: o usuário precisa corrigir o editor primeiro
    }
  };

  const openEditor = (addon: Addon, id: string | null) => {
    setDraft(JSON.stringify(addon, null, 2));
    setEditingId(id);
    setMessage(null);
  };

  const closeEditor = () => {
    setDraft(null);
    setEditingId(null);
    setMessage(null);
  };

  const importFromUrl = async () => {
    const url = importUrl.trim();
    if (!/^https:\/\//i.test(url)) {
      setMessage({ kind: 'error', text: 'A URL precisa começar com https://' });
      return;
    }
    setBusy(true);
    setMessage(null);
    try {
      const res = await fetch(url);
      if (!res.ok) throw new Error(`Erro HTTP ${res.status}`);
      const text = await res.text();
      setDraft(text);
      setEditingId(null);
      setMessage({ kind: 'info', text: 'Addon carregado. Revise, teste e salve.' });
    } catch (e) {
      setMessage({ kind: 'error', text: e instanceof Error ? e.message : String(e) });
    } finally {
      setBusy(false);
    }
  };

  const test = async () => {
    setBusy(true);
    setMessage(null);
    try {
      const addon = parseAddon(draft ?? '');
      const r = await runAddon(addon, { query: testQuery });
      setMessage({
        kind: 'ok',
        text: `✓ ${r.tracks.length} músicas prontas para tocar (${r.total} itens na resposta). Primeiro item bruto:`,
        sample: r.sample,
      });
    } catch (e) {
      setMessage({ kind: 'error', text: e instanceof Error ? e.message : String(e) });
    } finally {
      setBusy(false);
    }
  };

  const save = () => {
    try {
      const addon = parseAddon(draft ?? '');
      saveAddon(addon, editingId);
      closeEditor();
    } catch (e) {
      setMessage({ kind: 'error', text: e instanceof Error ? e.message : String(e) });
    }
  };

  const confirmRemove = (addon: Addon) => {
    Alert.alert('Remover fonte', `Remover "${addon.name}"?`, [
      { text: 'Cancelar', style: 'cancel' },
      { text: 'Remover', style: 'destructive', onPress: () => removeAddon(addon.id) },
    ]);
  };

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet" onRequestClose={onClose}>
      <View style={styles.screen}>
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Fontes (addons)</Text>
          <Pressable onPress={onClose} hitSlop={10}>
            <Text style={styles.close}>Fechar</Text>
          </Pressable>
        </View>

        <ScrollView
          contentContainerStyle={styles.content}
          keyboardShouldPersistTaps="handled"
          automaticallyAdjustKeyboardInsets
        >
          {draft === null ? (
            <>
              <Text style={styles.section}>Suas fontes</Text>
              {addons.length === 0 && <Text style={styles.muted}>Nenhuma fonte. Adicione uma abaixo.</Text>}
              {addons.map((a) => (
                <Pressable key={a.id} style={styles.row} onPress={() => setActive(a.id)}>
                  <Ionicons
                    name={a.id === activeId ? 'radio-button-on' : 'radio-button-off'}
                    size={22}
                    color={a.id === activeId ? colors.accent : colors.textMuted}
                  />
                  <View style={styles.rowInfo}>
                    <Text style={styles.rowTitle} numberOfLines={1}>
                      {a.name}
                    </Text>
                    <Text style={styles.muted} numberOfLines={1}>
                      {a.baseUrl ? a.baseUrl : 'sem baseUrl'} · {a.search ? 'busca' : ''}
                      {a.search && a.list ? ' + ' : ''}
                      {a.list ? 'lista' : ''}
                    </Text>
                  </View>
                  <Pressable onPress={() => openEditor(a, a.id)} hitSlop={8}>
                    <Ionicons name="create-outline" size={22} color={colors.text} />
                  </Pressable>
                  <Pressable onPress={() => confirmRemove(a)} hitSlop={8}>
                    <Ionicons name="trash-outline" size={22} color="#E5484D" />
                  </Pressable>
                </Pressable>
              ))}

              <Text style={styles.section}>Adicionar</Text>
              <View style={styles.chips}>
                {PRESETS.filter((p) => !addons.some((a) => a.id === p.id)).map((p) => (
                  <Pressable key={p.id} style={styles.chip} onPress={() => openEditor(p, null)}>
                    <Text style={styles.chipText}>+ {p.name}</Text>
                  </Pressable>
                ))}
                <Pressable style={styles.chip} onPress={() => openEditor(BLANK_ADDON, null)}>
                  <Text style={styles.chipText}>+ Em branco</Text>
                </Pressable>
              </View>

              <Text style={styles.label}>Importar addon de uma URL (.json)</Text>
              <View style={styles.inline}>
                <TextInput
                  style={[styles.input, styles.flex]}
                  value={importUrl}
                  onChangeText={setImportUrl}
                  placeholder="https://exemplo.com/addon.json"
                  placeholderTextColor={colors.textMuted}
                  autoCapitalize="none"
                  autoCorrect={false}
                  keyboardType="url"
                />
                <Pressable style={styles.button} onPress={importFromUrl} disabled={busy}>
                  {busy ? <ActivityIndicator color={colors.background} /> : <Text style={styles.buttonText}>Importar</Text>}
                </Pressable>
              </View>
              {message && <MessageBox message={message} />}
            </>
          ) : (
            <>
              <Text style={styles.section}>{editingId ? 'Editar fonte' : 'Nova fonte'}</Text>

              <Text style={styles.label}>baseUrl (endereço da API ou do .json)</Text>
              <TextInput
                style={styles.input}
                value={draftBaseUrl ?? ''}
                onChangeText={setDraftBaseUrl}
                editable={draftBaseUrl !== null}
                placeholder={draftBaseUrl === null ? 'JSON inválido: corrija abaixo' : 'https://sua-api.vercel.app'}
                placeholderTextColor={colors.textMuted}
                autoCapitalize="none"
                autoCorrect={false}
                keyboardType="url"
              />

              <Text style={styles.label}>Definição do addon (JSON)</Text>
              <TextInput
                style={styles.editor}
                value={draft}
                onChangeText={setDraft}
                multiline
                autoCapitalize="none"
                autoCorrect={false}
                spellCheck={false}
                scrollEnabled={false}
              />

              <Text style={styles.label}>Busca para testar</Text>
              <TextInput
                style={styles.input}
                value={testQuery}
                onChangeText={setTestQuery}
                placeholder="ex.: believer"
                placeholderTextColor={colors.textMuted}
                autoCapitalize="none"
                autoCorrect={false}
              />

              {message && <MessageBox message={message} />}

              <View style={styles.inline}>
                <Pressable style={[styles.button, styles.buttonGhost, styles.flex]} onPress={closeEditor}>
                  <Text style={styles.buttonGhostText}>Cancelar</Text>
                </Pressable>
                <Pressable style={[styles.button, styles.buttonGhost, styles.flex]} onPress={test} disabled={busy}>
                  {busy ? <ActivityIndicator color={colors.text} /> : <Text style={styles.buttonGhostText}>Testar</Text>}
                </Pressable>
                <Pressable style={[styles.button, styles.flex]} onPress={save}>
                  <Text style={styles.buttonText}>Salvar</Text>
                </Pressable>
              </View>
            </>
          )}
        </ScrollView>
      </View>
    </Modal>
  );
}

function MessageBox({ message }: { message: Message }) {
  const color = message.kind === 'error' ? '#E5484D' : message.kind === 'ok' ? '#3DD68C' : colors.textMuted;
  return (
    <View style={styles.message}>
      <Text style={[styles.messageText, { color }]}>{message.text}</Text>
      {message.sample ? <Text style={styles.sample}>{message.sample}</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.background },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: spacing.md,
  },
  headerTitle: { ...typography.title, color: colors.text },
  close: { ...typography.body, color: colors.text },
  content: { padding: spacing.md, gap: spacing.sm, paddingBottom: spacing.xl },
  section: { ...typography.title, color: colors.text, marginTop: spacing.md },
  label: { ...typography.caption, color: colors.textMuted, marginTop: spacing.sm },
  muted: { ...typography.caption, color: colors.textMuted },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    backgroundColor: colors.surface,
    borderRadius: 12,
    padding: spacing.md,
  },
  rowInfo: { flex: 1 },
  rowTitle: { ...typography.body, color: colors.text },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm },
  chip: { backgroundColor: colors.surfaceActive, borderRadius: 20, paddingVertical: 10, paddingHorizontal: 14 },
  chipText: { ...typography.caption, color: colors.text },
  inline: { flexDirection: 'row', gap: spacing.sm, alignItems: 'center' },
  flex: { flex: 1 },
  input: {
    ...typography.body,
    color: colors.text,
    backgroundColor: colors.surface,
    borderRadius: 10,
    paddingHorizontal: spacing.md,
    height: 44,
  },
  editor: {
    fontFamily: MONO,
    fontSize: 12,
    color: colors.text,
    backgroundColor: colors.surface,
    borderRadius: 10,
    padding: spacing.md,
    minHeight: 260,
    textAlignVertical: 'top',
  },
  button: {
    backgroundColor: colors.accent,
    borderRadius: 10,
    height: 44,
    paddingHorizontal: spacing.md,
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttonText: { ...typography.body, color: colors.background, fontWeight: '600' },
  buttonGhost: { backgroundColor: colors.surfaceActive },
  buttonGhostText: { ...typography.body, color: colors.text },
  message: { backgroundColor: colors.surface, borderRadius: 10, padding: spacing.md, gap: spacing.sm },
  messageText: { ...typography.caption },
  sample: { fontFamily: MONO, fontSize: 11, color: colors.textMuted },
});
