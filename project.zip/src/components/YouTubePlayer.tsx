import React, { useEffect, useMemo, useRef } from 'react';
import { StyleSheet, View } from 'react-native';
import { WebView, WebViewMessageEvent } from 'react-native-webview';
import { audioEngine, YouTubeController, YouTubeStatus } from '../services/audioEngine';
import { colors } from '../theme';

// Player OFICIAL do YouTube (IFrame Player API) dentro de uma WebView.
// Precisa ficar visível enquanto toca (regra do YouTube) e, por ser uma WebView,
// não toca com a tela bloqueada / app em segundo plano.

// Referer do app (recomendado pelo YouTube para apps; evita o erro 153)
const ORIGIN = 'https://com.seunome.musicplayer';

const HTML = `<!doctype html><html><head>
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<style>html,body{margin:0;height:100%;background:#000;overflow:hidden}#p{position:absolute;inset:0;width:100%;height:100%}</style>
</head><body><div id="p"></div>
<script>
var player=null, ready=false, queued=null, timer=null, last='';
function post(o){ window.ReactNativeWebView.postMessage(JSON.stringify(o)); }
var tag=document.createElement('script'); tag.src='https://www.youtube.com/iframe_api'; tag.onerror=function(){post({error:'Não consegui carregar o player do YouTube (sem internet?)'});};
document.head.appendChild(tag);
function onYouTubeIframeAPIReady(){
  player=new YT.Player('p',{
    width:'100%',height:'100%',
    playerVars:{playsinline:1,controls:1,rel:0,modestbranding:1,fs:0,origin:'${ORIGIN}'},
    events:{
      onReady:function(){ready=true; post({ready:true}); if(queued){var q=queued;queued=null;load(q.id,q.autoplay);} },
      onStateChange:function(e){ tick(e.data); },
      onError:function(e){
        var c=e.data, m='Erro do YouTube ('+c+')';
        if(c===101||c===150||c===153) m='O dono do vídeo não permite tocar fora do YouTube';
        else if(c===100) m='Vídeo removido ou privado';
        else if(c===2||c===5) m='Vídeo não pôde ser carregado';
        post({error:m});
      }
    }
  });
  timer=setInterval(function(){ if(ready) tick(); },500);
}
function tick(st){
  if(!ready) return;
  if(st===undefined) st=player.getPlayerState();
  var o={
    playing: st===1,
    buffering: st===3,
    loaded: st!==-1 && st!==5,
    position: player.getCurrentTime()||0,
    duration: player.getDuration()||0,
    ended: st===0
  };
  var key=JSON.stringify(o); if(key===last && st!==0) return; last=key; post(o);
}
function load(id,autoplay){
  last='';
  if(!ready){queued={id:id,autoplay:autoplay};return;}
  if(autoplay) player.loadVideoById(id); else player.cueVideoById(id);
}
function cmd(c){
  if(!ready) { if(c.a==='load') queued={id:c.id,autoplay:c.autoplay}; return; }
  if(c.a==='load') load(c.id,c.autoplay);
  else if(c.a==='play') player.playVideo();
  else if(c.a==='pause') player.pauseVideo();
  else if(c.a==='seek') player.seekTo(c.s,true);
  else if(c.a==='stop') player.stopVideo();
}
true;
</script></body></html>`;

export function YouTubePlayer() {
  const ref = useRef<WebView>(null);

  const controller = useMemo<YouTubeController>(() => {
    const send = (c: object) => ref.current?.injectJavaScript(`cmd(${JSON.stringify(c)});true;`);
    return {
      load: (id, autoplay) => send({ a: 'load', id, autoplay }),
      play: () => send({ a: 'play' }),
      pause: () => send({ a: 'pause' }),
      seekTo: (s) => send({ a: 'seek', s }),
      stop: () => send({ a: 'stop' }),
    };
  }, []);

  useEffect(() => {
    audioEngine.setYouTubeController(controller);
    return () => audioEngine.setYouTubeController(null);
  }, [controller]);

  const onMessage = (e: WebViewMessageEvent) => {
    try {
      const msg = JSON.parse(e.nativeEvent.data) as YouTubeStatus & { ready?: boolean };
      if (msg.ready) return;
      audioEngine.onYouTubeStatus(msg);
    } catch {
      /* mensagem inválida */
    }
  };

  return (
    <View style={styles.box}>
      <WebView
        ref={ref}
        style={styles.web}
        source={{ html: HTML, baseUrl: ORIGIN }}
        originWhitelist={['*']}
        javaScriptEnabled
        allowsInlineMediaPlayback
        mediaPlaybackRequiresUserAction={false}
        allowsFullscreenVideo={false}
        scrollEnabled={false}
        onMessage={onMessage}
        onError={() => audioEngine.onYouTubeStatus({ error: 'Falha ao carregar o player do YouTube' })}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  box: { aspectRatio: 16 / 9, width: '100%', backgroundColor: '#000', borderRadius: 12, overflow: 'hidden' },
  web: { flex: 1, backgroundColor: '#000' },
});
