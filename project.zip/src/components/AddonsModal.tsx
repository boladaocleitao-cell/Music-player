import React, { useState } from 'react';
import { ActivityIndicator, Alert, Modal, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAppStore } from '../store/appStore';
import { Addon } from '../addons/types';
import { TEMPLATES } from '../addons/templates';
import { parseAddon, prepareImport, runAddon } from '../addons/engine';
import { colors, spacing, typography } from '../theme';

type Message = { kind: 'ok' | 'error' | 'info'; text: string; sample?: string };
const MONO = Platform.select({ ios: 'Menlo', default: 'monospace' });

export function AddonsModal({ visible, onClose }: { visible: boolean; onClose: () => void }) {
  const addons = useAppStore((s) => s.addons);
  const saveAddon = useAppStore((s) => s.saveAddon);
  const removeAddon = useAppStore((s) => s.removeAddon);

  const [draft, setDraft] = useState<string | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [importUrl, setImportUrl] = useState('');
  const [testQuery, setTestQuery] = useState('');
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<Message | null>(null);

  const openEditor = (a: Addon, id: string | null) => {
    setDraft(JSON.stringify(a, null, 2));
    setEditingId(id);
    setMessage(null);
  };
  const closeEditor = () => {
    setDraft(null);
    setEditingId(null);
    setMessage(null);
  };
  const fail = (e: unknown) => setMessage({ kind: 'error', text: e instanceof Error ? e.message : String(e) });

  const importFromUrl = async () => {
    const url = importUrl.trim();
    if (!/^https:\/\//i.test(url)) return setMessage({ kind: 'error', text: 'A URL precisa começar com https://' });
    setBusy(true);
    setMessage(null);
    try {
      const res = await fetch(url);
      if (!res.ok) throw new Error(`Erro HTTP ${res.status}`);
      const { draft: d, generated } = prepareImport(await res.text(), url);
      setDraft(d);
      setEditingId(null);
      setMessage({
        kind: 'info',
        text: generated
          ? 'Esse link não é um addon, é uma lista/API em .json. Criei uma fonte "Lista JSON". Teste e salve.'
          : 'Addon carregado. Revise, teste e salve.',
      });
    } catch (e) {
      fail(e);
    } finally {
      setBusy(false);
    }
  };

  const test = async () => {
    setBusy(true);
    setMessage(null);
    try {
      const r = await runAddon(parseAddon(draft ?? ''), { query: testQuery });
      setMessage({ kind: 'ok', text: `✓ ${r.tracks.length} músicas prontas (${r.total} itens). Primeiro item bruto:`, sample: r.sample });
    } catch (e) {
      fail(e);
    } finally {
      setBusy(false);
    }
  };

  const save = () => {
    try {
      saveAddon(parseAddon(draft ?? ''), editingId);
      closeEditor();
    } catch (e) {
      fail(e);
    }
  };

  const confirmRemove = (a: Addon) =>
    Alert.alert('Remover fonte', `Remover "${a.name}"?`, [
      { text: 'Cancelar', style: 'cancel' },
      { text: 'Remover', style: 'destructive', onPress: () => removeAddon(a.id) },
    ]);

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet" onRequestClose={onClose}>
      <View style={styles.screen}>
        <View style={styles.header}>
          <Text style={styles.title}>Fontes extras (addons)</Text>
          <Pressable onPress={onClose} hitSlop={10}>
            <Text style={styles.link}>Fechar</Text>
          </Pressable>
        </View>

        <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled" automaticallyAdjustKeyboardInsets>
          {draft === null ? (
            <>
              {addons.length === 0 && <Text style={styles.muted}>Nenhum addon. O app usa só o YouTube.</Text>}
              {addons.map((a) => (
                <View key={a.id} style={styles.row}>
                  <View style={styles.flex}>
                    <Text style={styles.link} numberOfLines={1}>{a.name}</Text>
                    <Text style={styles.muted} numberOfLines={1}>{a.baseUrl || 'sem baseUrl'}</Text>
                  </View>
                  <Pressable onPress={() => openEditor(a, a.id)} hitSlop={8}>
                    <Ionicons name="create-outline" size={22} color={colors.text} />
                  </Pressable>
                  <Pressable onPress={() => confirmRemove(a)} hitSlop={8}>
                    <Ionicons name="trash-outline" size={22} color="#E5484D" />
                  </Pressable>
                </View>
              ))}

              <Text style={styles.label}>Novo a partir de um modelo</Text>
              <View style={styles.chips}>
                {TEMPLATES.map((t) => (
                  <Pressable key={t.id} style={styles.chip} onPress={() => openEditor(t, null)}>
                    <Text style={styles.chipText}>+ {t.name}</Text>
                  </Pressable>
                ))}
              </View>

              <Text style={styles.label}>Importar de uma URL (.json)</Text>
              <View style={styles.inline}>
                <TextInput
                  style={[styles.input, styles.flex]}
                  value={importUrl}
                  onChangeText={setImportUrl}
                  placeholder="https://exemplo.com/addon.json"
                  placeholderTextColor={colors.textMuted}
                  autoCapitalize="none"
                  autoCorrect={false}
                  keyboardType="url"
                />
                <Pressable style={styles.button} onPress={importFromUrl} disabled={busy}>
                  {busy ? <ActivityIndicator color={colors.onAccent} /> : <Text style={styles.buttonText}>Importar</Text>}
                </Pressable>
              </View>
              {message && <MessageBox m={message} />}
            </>
          ) : (
            <>
              <Text style={styles.label}>Definição do addon (JSON)</Text>
              <TextInput
                style={styles.editor}
                value={draft}
                onChangeText={setDraft}
                multiline
                autoCapitalize="none"
                autoCorrect={false}
                spellCheck={false}
                scrollEnabled={false}
              />
              <Text style={styles.label}>Busca para testar (vazio para listas)</Text>
              <TextInput
                style={styles.input}
                value={testQuery}
                onChangeText={setTestQuery}
                placeholderTextColor={colors.textMuted}
                autoCapitalize="none"
                autoCorrect={false}
              />
              {message && <MessageBox m={message} />}
              <View style={styles.inline}>
                <Pressable style={[styles.button, styles.ghost, styles.flex]} onPress={closeEditor}>
                  <Text style={styles.link}>Cancelar</Text>
                </Pressable>
                <Pressable style={[styles.button, styles.ghost, styles.flex]} onPress={test} disabled={busy}>
                  {busy ? <ActivityIndicator color={colors.text} /> : <Text style={styles.link}>Testar</Text>}
                </Pressable>
                <Pressable style={[styles.button, styles.flex]} onPress={save}>
                  <Text style={styles.buttonText}>Salvar</Text>
                </Pressable>
              </View>
            </>
          )}
        </ScrollView>
      </View>
    </Modal>
  );
}

function MessageBox({ m }: { m: Message }) {
  const color = m.kind === 'error' ? colors.danger : m.kind === 'ok' ? colors.ok : colors.textMuted;
  return (
    <View style={styles.message}>
      <Text style={[typography.caption, { color }]}>{m.text}</Text>
      {m.sample ? <Text style={styles.sample}>{m.sample}</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.background },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: spacing.md },
  title: { ...typography.title, color: colors.text },
  link: { ...typography.body, color: colors.text },
  content: { padding: spacing.md, gap: spacing.sm, paddingBottom: spacing.xl },
  label: { ...typography.caption, color: colors.textMuted, marginTop: spacing.sm },
  muted: { ...typography.caption, color: colors.textMuted },
  flex: { flex: 1 },
  row: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, backgroundColor: colors.surface, borderRadius: 12, padding: spacing.md },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm },
  chip: { backgroundColor: colors.surfaceActive, borderRadius: 20, paddingVertical: 10, paddingHorizontal: 14 },
  chipText: { ...typography.caption, color: colors.text },
  inline: { flexDirection: 'row', gap: spacing.sm, alignItems: 'center' },
  input: { ...typography.body, color: colors.text, backgroundColor: colors.surface, borderRadius: 10, paddingHorizontal: spacing.md, height: 44 },
  editor: { fontFamily: MONO, fontSize: 12, color: colors.text, backgroundColor: colors.surface, borderRadius: 10, padding: spacing.md, minHeight: 260, textAlignVertical: 'top' },
  button: { backgroundColor: colors.accent, borderRadius: 10, height: 44, paddingHorizontal: spacing.md, alignItems: 'center', justifyContent: 'center' },
  buttonText: { ...typography.body, color: colors.onAccent, fontWeight: '600' },
  ghost: { backgroundColor: colors.surfaceActive },
  message: { backgroundColor: colors.surface, borderRadius: 10, padding: spacing.md, gap: spacing.sm },
  sample: { fontFamily: MONO, fontSize: 11, color: colors.textMuted },
});
