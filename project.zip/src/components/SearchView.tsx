import React, { useState } from 'react';
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAppStore } from '../store/appStore';
import { playerActions } from '../hooks/usePlayer';
import { TrackList } from './TrackList';
import { colors, spacing, typography } from '../theme';

export function SearchView() {
  const { results, loading, error, searched, search, addons, sourceId, setSource } = useAppStore();
  const addon = addons.find((a) => a.id === sourceId);
  const [query, setQuery] = useState('');

  return (
    <View style={styles.flex}>
      {addons.length > 0 && (
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.chipsScroll} contentContainerStyle={styles.chips}>
          {[{ id: 'youtube', name: 'YouTube' }, ...addons].map((a) => (
            <Pressable key={a.id} onPress={() => setSource(a.id)} style={[styles.chip, a.id === sourceId && styles.chipActive]}>
              <Text style={[styles.chipText, a.id === sourceId && styles.chipTextActive]} numberOfLines={1}>
                {a.name}
              </Text>
            </Pressable>
          ))}
        </ScrollView>
      )}
      <View style={styles.searchBox}>
        <Ionicons name="search" size={18} color={colors.textMuted} />
        <TextInput
          style={styles.input}
          value={query}
          onChangeText={setQuery}
          onSubmitEditing={() => void search(query)}
          placeholder={addon ? (addon.search ? `Buscar em ${addon.name}` : `Filtrar ${addon.name}`) : 'Buscar no YouTube'}
          placeholderTextColor={colors.textMuted}
          returnKeyType="search"
          autoCorrect={false}
          autoCapitalize="none"
        />
        {loading ? (
          <ActivityIndicator color={colors.textMuted} />
        ) : query ? (
          <Pressable onPress={() => setQuery('')} hitSlop={10}>
            <Ionicons name="close-circle" size={18} color={colors.textMuted} />
          </Pressable>
        ) : null}
      </View>
      {error && <Text style={styles.error}>{error}</Text>}
      <TrackList
        tracks={results}
        onSelect={(i) => void playerActions.setQueue(results, i)}
        empty={searched ? (loading ? 'Buscando…' : 'Sem resultados.') : 'Digite e toque em buscar.'}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  chipsScroll: { flexGrow: 0, marginBottom: spacing.sm },
  chips: { paddingHorizontal: spacing.md, gap: spacing.sm },
  chip: { paddingVertical: 6, paddingHorizontal: 12, borderRadius: 16, backgroundColor: colors.surface, maxWidth: 200 },
  chipActive: { backgroundColor: colors.surfaceActive, borderWidth: 1, borderColor: colors.text },
  chipText: { ...typography.caption, color: colors.textMuted },
  chipTextActive: { color: colors.text },
  searchBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    backgroundColor: colors.surface,
    borderRadius: 10,
    paddingHorizontal: spacing.md,
    height: 44,
    marginHorizontal: spacing.md,
    marginBottom: spacing.sm,
  },
  input: { flex: 1, ...typography.body, color: colors.text },
  error: { ...typography.caption, color: '#E5484D', paddingHorizontal: spacing.md, paddingBottom: spacing.sm },
});
