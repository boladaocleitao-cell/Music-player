import React, { useState } from 'react';
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAppStore } from '../store/appStore';
import { playerActions } from '../hooks/usePlayer';
import { TrackList } from './TrackList';
import { Glass } from './Glass';
import { Press } from './Press';
import { colors, spacing, typography } from '../theme';

export function SearchView({ bottomPad }: { bottomPad: number }) {
  const { results, loading, error, searched, search, addons, sourceId, setSource } = useAppStore();
  const [query, setQuery] = useState('');
  const addon = addons.find((a) => a.id === sourceId);

  return (
    <View style={styles.flex}>
      <Text style={styles.heading}>Buscar</Text>
      <Glass style={styles.searchBox} radius={22} intensity={40}>
        <View style={styles.searchInner}>
          <Ionicons name="search" size={18} color={colors.textMuted} />
          <TextInput
            style={styles.input}
            value={query}
            onChangeText={setQuery}
            onSubmitEditing={() => void search(query)}
            placeholder={addon ? (addon.search ? `Buscar em ${addon.name}` : `Filtrar ${addon.name}`) : 'Artistas, músicas, álbuns…'}
            placeholderTextColor={colors.textMuted}
            returnKeyType="search"
            autoCorrect={false}
            autoCapitalize="none"
            selectionColor={colors.accent}
          />
          {loading ? (
            <ActivityIndicator color={colors.textMuted} />
          ) : query ? (
            <Pressable onPress={() => setQuery('')} hitSlop={10}>
              <Ionicons name="close-circle" size={18} color={colors.textMuted} />
            </Pressable>
          ) : null}
        </View>
      </Glass>

      {addons.length > 0 && (
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.chipsScroll} contentContainerStyle={styles.chips}>
          {[{ id: 'youtube', name: 'YouTube' }, ...addons].map((a) => (
            <Press key={a.id} onPress={() => setSource(a.id)} scaleTo={0.94} inner={[styles.chip, a.id === sourceId && styles.chipActive]}>
              <Text style={[styles.chipText, a.id === sourceId && styles.chipTextActive]} numberOfLines={1}>{a.name}</Text>
            </Press>
          ))}
        </ScrollView>
      )}

      {error && <Text style={styles.error}>{error}</Text>}
      <TrackList
        tracks={results}
        bottomPad={bottomPad}
        onSelect={(i) => void playerActions.setQueue(results, i)}
        empty={searched ? (loading ? 'Buscando…' : 'Sem resultados.') : 'Digite e toque em buscar.'}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  heading: { ...typography.hero, color: colors.text, paddingHorizontal: spacing.md, paddingTop: spacing.sm, paddingBottom: spacing.md },
  searchBox: { marginHorizontal: spacing.md, height: 48, marginBottom: spacing.sm },
  searchInner: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: spacing.sm, paddingHorizontal: spacing.md },
  input: { flex: 1, ...typography.body, color: colors.text },
  chipsScroll: { flexGrow: 0, marginBottom: spacing.sm },
  chips: { paddingHorizontal: spacing.md, gap: spacing.sm },
  chip: { paddingVertical: 7, paddingHorizontal: 14, borderRadius: 18, backgroundColor: colors.surface, maxWidth: 200 },
  chipActive: { backgroundColor: colors.surfaceActive, borderWidth: 1, borderColor: colors.accent },
  chipText: { ...typography.caption, color: colors.textMuted },
  chipTextActive: { color: colors.text },
  error: { ...typography.caption, color: colors.danger, paddingHorizontal: spacing.md, paddingBottom: spacing.sm },
});
