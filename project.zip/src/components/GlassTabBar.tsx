import React, { useEffect, useRef, useState } from 'react';
import { Animated, LayoutChangeEvent, StyleSheet, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Glass } from './Glass';
import { Press } from './Press';
import { colors } from '../theme';

export type Tab = 'home' | 'search' | 'library';

const TABS: { id: Tab; on: keyof typeof Ionicons.glyphMap; off: keyof typeof Ionicons.glyphMap }[] = [
  { id: 'home', on: 'planet', off: 'planet-outline' },
  { id: 'search', on: 'search', off: 'search-outline' },
  { id: 'library', on: 'heart', off: 'heart-outline' },
];

export const TAB_BAR_HEIGHT = 64;

// Barra flutuante só com ícones; uma "bolha" de vidro desliza até a aba ativa
export function GlassTabBar({ tab, onChange }: { tab: Tab; onChange: (t: Tab) => void }) {
  const [width, setWidth] = useState(0);
  const x = useRef(new Animated.Value(0)).current;
  const cell = width / TABS.length;
  const idx = TABS.findIndex((t) => t.id === tab);

  useEffect(() => {
    if (!cell) return;
    Animated.spring(x, { toValue: idx * cell, useNativeDriver: true, speed: 14, bounciness: 10 }).start();
  }, [idx, cell, x]);

  return (
    <Glass style={styles.bar} radius={TAB_BAR_HEIGHT / 2} intensity={60}>
      <View style={styles.row} onLayout={(e: LayoutChangeEvent) => setWidth(e.nativeEvent.layout.width)}>
        {cell > 0 && (
          <Animated.View style={[styles.bubble, { width: cell - 8, transform: [{ translateX: Animated.add(x, new Animated.Value(4)) }] }]} />
        )}
        {TABS.map((t) => (
          <Press key={t.id} style={styles.cellOuter} inner={styles.cell} onPress={() => onChange(t.id)} scaleTo={0.85}>
            <Ionicons name={t.id === tab ? t.on : t.off} size={26} color={t.id === tab ? colors.text : colors.textMuted} />
          </Press>
        ))}
      </View>
    </Glass>
  );
}

const styles = StyleSheet.create({
  bar: { height: TAB_BAR_HEIGHT, marginHorizontal: 28 },
  row: { flex: 1, flexDirection: 'row', alignItems: 'center' },
  cellOuter: { flex: 1 },
  cell: { height: TAB_BAR_HEIGHT, alignItems: 'center', justifyContent: 'center' },
  bubble: {
    position: 'absolute',
    left: 0,
    top: 6,
    height: TAB_BAR_HEIGHT - 12,
    borderRadius: (TAB_BAR_HEIGHT - 12) / 2,
    backgroundColor: 'rgba(167,139,250,0.28)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.25)',
  },
});
