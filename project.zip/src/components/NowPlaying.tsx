import React from 'react';
import { Image, StyleSheet, Text, View } from 'react-native';
import { usePlayer } from '../hooks/usePlayer';
import { colors, spacing, typography } from '../theme';

export function NowPlaying() {
  const { track, error } = usePlayer();

  return (
    <View style={styles.row}>
      {track?.artwork ? (
        <Image source={{ uri: track.artwork }} style={styles.art} />
      ) : (
        <View style={[styles.art, styles.artEmpty]} />
      )}
      <View style={styles.info}>
        <Text style={styles.title} numberOfLines={1}>
          {track?.title ?? 'Nada tocando'}
        </Text>
        <Text style={error ? styles.error : styles.artist} numberOfLines={2}>
          {error ? error : track?.artist ?? 'Escolha uma música'}
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  art: { width: 56, height: 56, borderRadius: 8, backgroundColor: colors.surface },
  artEmpty: { backgroundColor: colors.surfaceActive },
  info: { flex: 1 },
  title: { ...typography.title, color: colors.text },
  artist: { ...typography.body, color: colors.textMuted, marginTop: 2 },
  error: { ...typography.body, color: '#E5484D', marginTop: 2 },
});
