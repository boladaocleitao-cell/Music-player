import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Animated,
  Image,
  PanResponder,
  StyleSheet,
  Text,
  View,
  useWindowDimensions,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { usePlayer } from '../hooks/usePlayer';
import { useAppStore } from '../store/appStore';
import { Glass } from './Glass';
import { Press } from './Press';
import { MiniProgress, ProgressBar } from './ProgressBar';
import { YouTubePlayer } from './YouTubePlayer';
import { colors, spacing, typography } from '../theme';

const PAD = 8; // margem interna do cartão recolhido
const MINI_ROW = 52;

/** Altura do cartão recolhido (vídeo 16:9 + linha de controles + progresso) */
export function collapsedHeight(width: number): number {
  const videoH = ((width - 32) * 9) / 16;
  return PAD + videoH + 8 + MINI_ROW + 8 + 3 + PAD;
}

// Player próprio: recolhido = cartão de vidro flutuante; aberto = tela cheia.
// O vídeo oficial do YouTube é UM só componente e fica sempre visível nos dois estados
// (regra do YouTube: o player não pode ser escondido).
export function PlayerSheet({ bottomOffset }: { bottomOffset: number }) {
  const { width: W, height: H } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const {
    track, isPlaying, isBuffering, error, shuffle, repeat,
    toggle, next, previous, toggleShuffle, cycleRepeat,
  } = usePlayer();
  const favorites = useAppStore((s) => s.favorites);
  const toggleFavorite = useAppStore((s) => s.toggleFavorite);
  const isFav = track ? favorites.some((t) => t.id === track.id) : false;

  const Hc = collapsedHeight(W);
  const videoW = W - 32;
  const videoH = (videoW * 9) / 16;

  const p = useRef(new Animated.Value(0)).current; // 0 recolhido, 1 aberto
  const enter = useRef(new Animated.Value(0)).current; // entrada do cartão
  const [expanded, setExpanded] = useState(false);
  const expandedRef = useRef(false);

  const go = (to: 0 | 1) => {
    expandedRef.current = to === 1;
    setExpanded(to === 1);
    Animated.spring(p, { toValue: to, useNativeDriver: false, speed: 12, bounciness: 6 }).start();
  };

  const hasTrack = !!track;
  useEffect(() => {
    Animated.spring(enter, { toValue: hasTrack ? 1 : 0, useNativeDriver: true, speed: 10, bounciness: 8 }).start();
  }, [hasTrack, enter]);

  // arrastar o cabeçalho para baixo fecha a tela cheia
  const pan = useMemo(
    () =>
      PanResponder.create({
        onMoveShouldSetPanResponder: (_, g) => expandedRef.current && g.dy > 8 && Math.abs(g.dy) > Math.abs(g.dx),
        onPanResponderMove: (_, g) => p.setValue(Math.max(0, Math.min(1, 1 - g.dy / (H * 0.6)))),
        onPanResponderRelease: (_, g) => go(g.dy > 120 || g.vy > 1 ? 0 : 1),
      }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [H]
  );

  if (!track) return null;

  const top = p.interpolate({ inputRange: [0, 1], outputRange: [H - bottomOffset - Hc, 0] });
  const height = p.interpolate({ inputRange: [0, 1], outputRange: [Hc, H] });
  const side = p.interpolate({ inputRange: [0, 1], outputRange: [8, 0] });
  const radius = p.interpolate({ inputRange: [0, 1], outputRange: [28, 0] });
  const glassOpacity = p.interpolate({ inputRange: [0, 1], outputRange: [1, 0] });
  const slide = enter.interpolate({ inputRange: [0, 1], outputRange: [Hc + bottomOffset, 0] });

  const art = track.artwork;
  const playIcon = (size: number, color: string) =>
    isBuffering && !isPlaying ? (
      <ActivityIndicator color={color} />
    ) : (
      <Ionicons name={isPlaying ? 'pause' : 'play'} size={size} color={color} style={isPlaying ? undefined : styles.nudge} />
    );

  return (
    <Animated.View pointerEvents="box-none" style={[StyleSheet.absoluteFill, { transform: [{ translateY: slide }] }]}>
      <Animated.View style={[styles.sheet, { top, height, left: side, right: side, borderRadius: radius }]}>
        {/* fundo recolhido: vidro */}
        <Animated.View pointerEvents="none" style={[StyleSheet.absoluteFill, { opacity: glassOpacity }]}>
          <Glass style={StyleSheet.absoluteFill} radius={28} intensity={70} />
        </Animated.View>
        {/* fundo aberto: capa desfocada + roxo */}
        <Animated.View pointerEvents="none" style={[StyleSheet.absoluteFill, { opacity: p, backgroundColor: colors.background }]}>
          {art ? <Image source={{ uri: art }} blurRadius={60} style={[StyleSheet.absoluteFill, styles.bgArt]} /> : null}
          <LinearGradient
            colors={['rgba(124,58,237,0.55)', 'rgba(13,8,24,0.92)']}
            style={StyleSheet.absoluteFill}
          />
        </Animated.View>

        <View
          style={{
            flex: 1,
            paddingHorizontal: expanded ? 16 : PAD,
            paddingTop: expanded ? insets.top + 4 : PAD,
            paddingBottom: expanded ? insets.bottom + 12 : PAD,
          }}
        >
          {/* cabeçalho (só aberto) */}
          <View style={expanded ? styles.header : styles.hidden} {...pan.panHandlers}>
            <Press onPress={() => go(0)} hitSlop={12} style={styles.headerBtn} inner={styles.headerBtnInner}>
              <Ionicons name="chevron-down" size={24} color={colors.text} />
            </Press>
            <Text style={styles.headerTitle} numberOfLines={1}>
              Tocando agora
            </Text>
            <View style={styles.headerBtn} />
          </View>

          {/* vídeo oficial do YouTube: sempre visível, mesmo nó nos dois estados */}
          <View style={[styles.video, { width: videoW, height: videoH }]}>
            <YouTubePlayer />
          </View>

          {/* corpo recolhido */}
          <View style={expanded ? styles.hidden : styles.mini}>
            <View style={styles.miniRow}>
              <Press onPress={() => go(1)} style={styles.flex} inner={styles.miniInfo}>
                {art ? <Image source={{ uri: art }} style={styles.miniArt} /> : <View style={[styles.miniArt, styles.artEmpty]} />}
                <View style={styles.flex}>
                  <Text style={styles.miniTitle} numberOfLines={1}>{track.title}</Text>
                  <Text style={error ? styles.error : styles.miniArtist} numberOfLines={1}>
                    {error ?? track.artist}
                  </Text>
                </View>
              </Press>
              <Press onPress={toggle} hitSlop={8} inner={styles.miniBtn}>{playIcon(26, colors.text)}</Press>
              <Press onPress={next} hitSlop={8} inner={styles.miniBtn}>
                <Ionicons name="play-skip-forward" size={26} color={colors.text} />
              </Press>
            </View>
            <MiniProgress />
          </View>

          {/* corpo aberto */}
          <View style={expanded ? styles.body : styles.hidden}>
            <View style={styles.titleRow}>
              <View style={styles.flex}>
                <Text style={styles.title} numberOfLines={2}>{track.title}</Text>
                <Text style={styles.artist} numberOfLines={1}>{track.artist}</Text>
              </View>
              <Press onPress={() => toggleFavorite(track)} hitSlop={10} scaleTo={0.7} inner={styles.heart}>
                <Ionicons name={isFav ? 'heart' : 'heart-outline'} size={28} color={isFav ? colors.accent : colors.text} />
              </Press>
            </View>
            {error ? <Text style={styles.error}>{error}</Text> : null}

            <ProgressBar />

            <View style={styles.controls}>
              <Press onPress={toggleShuffle} hitSlop={10} inner={styles.sideBtn}>
                <Ionicons name="shuffle" size={24} color={shuffle ? colors.accent : colors.textMuted} />
              </Press>
              <Press onPress={previous} hitSlop={10} inner={styles.sideBtn}>
                <Ionicons name="play-skip-back" size={34} color={colors.text} />
              </Press>
              <Press onPress={toggle} scaleTo={0.9} inner={styles.playBtn}>{playIcon(36, colors.onAccent)}</Press>
              <Press onPress={next} hitSlop={10} inner={styles.sideBtn}>
                <Ionicons name="play-skip-forward" size={34} color={colors.text} />
              </Press>
              <Press onPress={cycleRepeat} hitSlop={10} inner={styles.sideBtn}>
                <Ionicons name="repeat" size={24} color={repeat === 'off' ? colors.textMuted : colors.accent} />
                {repeat === 'one' && <Text style={styles.one}>1</Text>}
              </Press>
            </View>
          </View>
        </View>
      </Animated.View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  hidden: { display: 'none' },
  sheet: { position: 'absolute', overflow: 'hidden' },
  bgArt: { opacity: 0.6 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', height: 48 },
  headerBtn: { width: 44 },
  headerBtnInner: { width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(255,255,255,0.12)' },
  headerTitle: { ...typography.body, color: colors.text, fontWeight: '700' },
  video: { alignSelf: 'center', borderRadius: 16, overflow: 'hidden', backgroundColor: '#000', marginTop: 4 },
  mini: { marginTop: 8, gap: 8 },
  miniRow: { flexDirection: 'row', alignItems: 'center', height: MINI_ROW, gap: spacing.sm },
  miniInfo: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  miniArt: { width: 44, height: 44, borderRadius: 8, backgroundColor: colors.surface },
  artEmpty: { backgroundColor: colors.surfaceActive },
  miniTitle: { ...typography.body, color: colors.text, fontWeight: '700' },
  miniArtist: { ...typography.caption, color: colors.textMuted, marginTop: 2 },
  miniBtn: { width: 44, height: 44, alignItems: 'center', justifyContent: 'center' },
  body: { flex: 1, justifyContent: 'space-evenly', paddingTop: spacing.md },
  titleRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  title: { fontSize: 24, fontWeight: '800', color: colors.text },
  artist: { ...typography.title, color: colors.textMuted, marginTop: 2, fontWeight: '500' },
  heart: { width: 48, height: 48, alignItems: 'center', justifyContent: 'center', borderRadius: 24, backgroundColor: 'rgba(255,255,255,0.12)' },
  error: { ...typography.caption, color: colors.danger },
  controls: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  sideBtn: { width: 48, height: 48, alignItems: 'center', justifyContent: 'center' },
  playBtn: { width: 76, height: 76, borderRadius: 38, backgroundColor: colors.text, alignItems: 'center', justifyContent: 'center' },
  nudge: { marginLeft: 3 },
  one: { position: 'absolute', fontSize: 9, fontWeight: '800', color: colors.accent, top: 15 },
});
