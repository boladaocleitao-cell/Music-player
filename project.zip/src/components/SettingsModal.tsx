import React, { useEffect, useState } from 'react';
import { Modal, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { useAppStore } from '../store/appStore';
import { AddonsModal } from './AddonsModal';
import { colors, spacing, typography } from '../theme';

export function SettingsModal({ visible, onClose }: { visible: boolean; onClose: () => void }) {
  const apiKey = useAppStore((s) => s.apiKey);
  const setApiKey = useAppStore((s) => s.setApiKey);
  const [value, setValue] = useState(apiKey);
  const [showAddons, setShowAddons] = useState(false);
  const addonCount = useAppStore((s) => s.addons.length);

  useEffect(() => {
    if (visible) setValue(apiKey);
  }, [visible, apiKey]);

  const save = () => {
    setApiKey(value);
    onClose();
  };

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet" onRequestClose={onClose}>
      <View style={styles.screen}>
        <View style={styles.header}>
          <Text style={styles.title}>Configurações</Text>
          <Pressable onPress={onClose} hitSlop={10}>
            <Text style={styles.link}>Fechar</Text>
          </Pressable>
        </View>
        <Text style={styles.label}>Chave da API do YouTube (YouTube Data API v3)</Text>
        <TextInput
          style={styles.input}
          value={value}
          onChangeText={setValue}
          placeholder="AIza..."
          placeholderTextColor={colors.textMuted}
          autoCapitalize="none"
          autoCorrect={false}
          secureTextEntry
        />
        <Text style={styles.hint}>
          Cada busca gasta ~100 unidades da cota diária (10.000). Músicas já tocadas ficam em cache e não gastam de novo.
        </Text>
        <Pressable style={styles.button} onPress={save}>
          <Text style={styles.buttonText}>Salvar</Text>
        </Pressable>
        <Pressable style={[styles.button, styles.ghost]} onPress={() => setShowAddons(true)}>
          <Text style={styles.link}>Fontes extras (addons){addonCount ? ` · ${addonCount}` : ''}</Text>
        </Pressable>
        <Text style={styles.hint}>
          Addons são receitas em JSON criadas por você ou pela comunidade. Use por sua conta e risco: confira se tem direito de usar o conteúdo da fonte.
        </Text>
        <AddonsModal visible={showAddons} onClose={() => setShowAddons(false)} />
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.background, padding: spacing.md, gap: spacing.sm },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: spacing.md },
  title: { ...typography.title, color: colors.text },
  link: { ...typography.body, color: colors.text },
  label: { ...typography.caption, color: colors.textMuted },
  input: { ...typography.body, color: colors.text, backgroundColor: colors.surface, borderRadius: 10, paddingHorizontal: spacing.md, height: 44 },
  hint: { ...typography.caption, color: colors.textMuted },
  button: { backgroundColor: colors.accent, borderRadius: 14, height: 44, alignItems: 'center', justifyContent: 'center', marginTop: spacing.sm },
  ghost: { backgroundColor: colors.surfaceActive },
  buttonText: { ...typography.body, color: colors.onAccent, fontWeight: '600' },
});
