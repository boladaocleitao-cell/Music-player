import React, { useEffect, useState } from 'react';
import { StyleSheet, View } from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { useWindowDimensions } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useAppStore } from '../store/appStore';
import { usePlayer } from '../hooks/usePlayer';
import { HomeView } from '../components/HomeView';
import { SearchView } from '../components/SearchView';
import { LibraryView } from '../components/LibraryView';
import { SettingsModal } from '../components/SettingsModal';
import { GlassTabBar, TAB_BAR_HEIGHT, Tab } from '../components/GlassTabBar';
import { PlayerSheet, collapsedHeight } from '../components/PlayerSheet';
import { colors } from '../theme';

export function PlayerScreen() {
  const apiKey = useAppStore((s) => s.apiKey);
  const hydrated = useAppStore((s) => s.hydrated);
  const addRecent = useAppStore((s) => s.addRecent);
  const { track } = usePlayer();
  const insets = useSafeAreaInsets();
  const { width } = useWindowDimensions();

  const [tab, setTab] = useState<Tab>('home');
  const [showSettings, setShowSettings] = useState(false);

  // Primeiro uso: pede a chave do YouTube
  useEffect(() => {
    if (hydrated && !apiKey) setShowSettings(true);
  }, [hydrated, apiKey]);

  // histórico (aba Biblioteca → Recentes)
  const trackId = track?.id;
  useEffect(() => {
    if (track) addRecent(track);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [trackId]);

  const barBottom = Math.max(insets.bottom, 12);
  const bottomOffset = barBottom + TAB_BAR_HEIGHT + 10; // base do cartão do player
  const listPad = bottomOffset + (track ? collapsedHeight(width) : 0) + 16;

  return (
    <View style={styles.screen}>
      <LinearGradient colors={[colors.backgroundTop, colors.background]} style={styles.glow} />
      <SafeAreaView style={styles.flex} edges={['top']}>
        <View style={styles.flex}>
          {tab === 'home' && <HomeView bottomPad={listPad} onSettings={() => setShowSettings(true)} />}
          {tab === 'search' && <SearchView bottomPad={listPad} />}
          {tab === 'library' && <LibraryView bottomPad={listPad} />}
        </View>
      </SafeAreaView>

      <View pointerEvents="box-none" style={[styles.barWrap, { bottom: barBottom }]}>
        <GlassTabBar tab={tab} onChange={setTab} />
      </View>

      <PlayerSheet bottomOffset={bottomOffset} />

      <SettingsModal visible={showSettings} onClose={() => setShowSettings(false)} />
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.background },
  flex: { flex: 1 },
  glow: { position: 'absolute', top: 0, left: 0, right: 0, height: 420 },
  barWrap: { position: 'absolute', left: 0, right: 0 },
});
