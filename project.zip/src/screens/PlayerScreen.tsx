import React, { useEffect, useState } from 'react';
import { ActivityIndicator, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useAppStore } from '../store/appStore';
import { playerActions } from '../hooks/usePlayer';
import { TrackList } from '../components/TrackList';
import { NowPlaying } from '../components/NowPlaying';
import { ProgressBar } from '../components/ProgressBar';
import { Controls } from '../components/Controls';
import { colors, spacing, typography } from '../theme';

export function PlayerScreen() {
  const { apiUrl, hydrated, results, loading, error, setApiUrl, search } = useAppStore();

  const [query, setQuery] = useState('');
  const [urlDraft, setUrlDraft] = useState('');
  const [showSettings, setShowSettings] = useState(false);

  // Quando a URL salva carrega, preenche o campo; sem URL, abre as configurações
  useEffect(() => {
    if (!hydrated) return;
    setUrlDraft(apiUrl);
    if (!apiUrl) setShowSettings(true);
  }, [hydrated, apiUrl]);

  const submitSearch = () => {
    void search(query);
  };

  return (
    <SafeAreaView style={styles.screen} edges={['top', 'bottom']}>
      <View style={styles.header}>
        <View style={styles.searchBox}>
          <Ionicons name="search" size={18} color={colors.textMuted} />
          <TextInput
            style={styles.searchInput}
            value={query}
            onChangeText={setQuery}
            onSubmitEditing={submitSearch}
            placeholder="Buscar músicas"
            placeholderTextColor={colors.textMuted}
            returnKeyType="search"
            autoCorrect={false}
          />
          {loading && <ActivityIndicator color={colors.textMuted} />}
        </View>
        <Pressable onPress={() => setShowSettings((v) => !v)} hitSlop={10}>
          <Ionicons name="settings-outline" size={22} color={colors.text} />
        </Pressable>
      </View>

      {showSettings && (
        <View style={styles.settings}>
          <Text style={styles.label}>URL da API (https://…)</Text>
          <TextInput
            style={styles.urlInput}
            value={urlDraft}
            onChangeText={setUrlDraft}
            onEndEditing={() => void setApiUrl(urlDraft)}
            placeholder="https://sua-api.vercel.app"
            placeholderTextColor={colors.textMuted}
            autoCapitalize="none"
            autoCorrect={false}
            keyboardType="url"
            returnKeyType="done"
          />
        </View>
      )}

      {error && <Text style={styles.error}>{error}</Text>}

      <View style={styles.list}>
        <TrackList tracks={results} onSelect={(i) => void playerActions.setQueue(results, i)} />
      </View>

      <View style={styles.player}>
        <NowPlaying />
        <ProgressBar />
        <Controls />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.background },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
  },
  searchBox: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    backgroundColor: colors.surface,
    borderRadius: 10,
    paddingHorizontal: spacing.md,
    height: 44,
  },
  searchInput: { flex: 1, ...typography.body, color: colors.text },
  settings: { paddingHorizontal: spacing.md, paddingBottom: spacing.sm, gap: spacing.xs },
  label: { ...typography.caption, color: colors.textMuted },
  urlInput: {
    ...typography.body,
    color: colors.text,
    backgroundColor: colors.surface,
    borderRadius: 10,
    paddingHorizontal: spacing.md,
    height: 44,
  },
  error: { ...typography.caption, color: '#E5484D', paddingHorizontal: spacing.md, paddingBottom: spacing.sm },
  list: { flex: 1 },
  player: {
    gap: spacing.sm,
    padding: spacing.md,
    backgroundColor: colors.surface,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
  },
});
