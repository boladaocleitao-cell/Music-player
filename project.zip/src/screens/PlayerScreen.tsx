import React, { useEffect, useState } from 'react';
import { ActivityIndicator, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useAppStore } from '../store/appStore';
import { playerActions } from '../hooks/usePlayer';
import { TrackList } from '../components/TrackList';
import { NowPlaying } from '../components/NowPlaying';
import { ProgressBar } from '../components/ProgressBar';
import { Controls } from '../components/Controls';
import { SourcesModal } from '../components/SourcesModal';
import { colors, spacing, typography } from '../theme';

export function PlayerScreen() {
  const { addons, activeId, hydrated, results, loading, error, search } = useAppStore();

  const [query, setQuery] = useState('');
  const [showSources, setShowSources] = useState(false);

  const active = addons.find((a) => a.id === activeId) ?? null;

  // Primeiro uso: sem fonte ativa, abre o gerenciador de fontes
  useEffect(() => {
    if (hydrated && !activeId) setShowSources(true);
  }, [hydrated, activeId]);

  const submitSearch = () => {
    void search(query);
  };

  return (
    <SafeAreaView style={styles.screen} edges={['top', 'bottom']}>
      <View style={styles.header}>
        <View style={styles.searchBox}>
          <Ionicons name="search" size={18} color={colors.textMuted} />
          <TextInput
            style={styles.searchInput}
            value={query}
            onChangeText={setQuery}
            onSubmitEditing={submitSearch}
            placeholder={active && !active.search ? 'Filtrar a lista' : 'Buscar músicas'}
            placeholderTextColor={colors.textMuted}
            returnKeyType="search"
            autoCorrect={false}
          />
          {loading && <ActivityIndicator color={colors.textMuted} />}
        </View>
        <Pressable onPress={() => setShowSources(true)} hitSlop={10}>
          <Ionicons name="settings-outline" size={22} color={colors.text} />
        </Pressable>
      </View>

      <Pressable style={styles.source} onPress={() => setShowSources(true)}>
        <Ionicons name="extension-puzzle-outline" size={14} color={colors.textMuted} />
        <Text style={styles.sourceText} numberOfLines={1}>
          Fonte: {active ? active.name : 'nenhuma (toque para escolher)'}
        </Text>
      </Pressable>

      {error && <Text style={styles.error}>{error}</Text>}

      <View style={styles.list}>
        <TrackList tracks={results} onSelect={(i) => void playerActions.setQueue(results, i)} />
      </View>

      <View style={styles.player}>
        <NowPlaying />
        <ProgressBar />
        <Controls />
      </View>

      <SourcesModal visible={showSources} onClose={() => setShowSources(false)} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.background },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
  },
  searchBox: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    backgroundColor: colors.surface,
    borderRadius: 10,
    paddingHorizontal: spacing.md,
    height: 44,
  },
  searchInput: { flex: 1, ...typography.body, color: colors.text },
  source: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    paddingHorizontal: spacing.md,
    paddingBottom: spacing.sm,
  },
  sourceText: { ...typography.caption, color: colors.textMuted, flex: 1 },
  error: { ...typography.caption, color: '#E5484D', paddingHorizontal: spacing.md, paddingBottom: spacing.sm },
  list: { flex: 1 },
  player: {
    gap: spacing.sm,
    padding: spacing.md,
    backgroundColor: colors.surface,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
  },
});
