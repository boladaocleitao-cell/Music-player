import React, { useEffect, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useAppStore } from '../store/appStore';
import { usePlayer } from '../hooks/usePlayer';
import { HomeView } from '../components/HomeView';
import { SearchView } from '../components/SearchView';
import { SettingsModal } from '../components/SettingsModal';
import { NowPlaying } from '../components/NowPlaying';
import { ProgressBar } from '../components/ProgressBar';
import { Controls } from '../components/Controls';
import { YouTubePlayer } from '../components/YouTubePlayer';
import { colors, spacing, typography } from '../theme';

type Tab = 'home' | 'search';

export function PlayerScreen() {
  const apiKey = useAppStore((s) => s.apiKey);
  const hydrated = useAppStore((s) => s.hydrated);
  const { track } = usePlayer();

  const [tab, setTab] = useState<Tab>('home');
  const [showSettings, setShowSettings] = useState(false);

  // Primeiro uso: pede a chave do YouTube
  useEffect(() => {
    if (hydrated && !apiKey) setShowSettings(true);
  }, [hydrated, apiKey]);

  return (
    <SafeAreaView style={styles.screen} edges={['top', 'bottom']}>
      <View style={styles.header}>
        <View style={styles.tabs}>
          {(['home', 'search'] as const).map((t) => (
            <Pressable key={t} onPress={() => setTab(t)} style={[styles.tab, tab === t && styles.tabActive]}>
              <Text style={[styles.tabText, tab === t && styles.tabTextActive]}>
                {t === 'home' ? 'Home' : 'Buscar'}
              </Text>
            </Pressable>
          ))}
        </View>
        <Pressable onPress={() => setShowSettings(true)} hitSlop={10}>
          <Ionicons name="settings-outline" size={22} color={colors.text} />
        </Pressable>
      </View>

      <View style={styles.content}>{tab === 'home' ? <HomeView /> : <SearchView />}</View>

      {/* Player próprio. O vídeo do YouTube fica sempre visível enquanto há faixa (regra do YouTube). */}
      {track && (
        <View style={styles.player}>
          <YouTubePlayer />
          <NowPlaying />
          <ProgressBar />
          <Controls />
        </View>
      )}

      <SettingsModal visible={showSettings} onClose={() => setShowSettings(false)} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.background },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
  },
  tabs: { flexDirection: 'row', gap: spacing.sm },
  tab: { paddingVertical: 8, paddingHorizontal: 16, borderRadius: 20, backgroundColor: colors.surface },
  tabActive: { backgroundColor: colors.accent },
  tabText: { ...typography.body, color: colors.text },
  tabTextActive: { color: colors.background, fontWeight: '600' },
  content: { flex: 1 },
  player: {
    gap: spacing.sm,
    padding: spacing.md,
    backgroundColor: colors.surface,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
  },
});
