import { create } from 'zustand';
import { INITIAL_TRACKS } from '../data/tracks';
import { searchSongs } from '../services/jiosaavn';
import { getApiUrl, setApiUrl as saveApiUrl } from '../services/settings';
import { Track } from '../types/track';

interface AppState {
  apiUrl: string;
  hydrated: boolean;
  results: Track[];
  loading: boolean;
  error: string | null;
  hydrate: () => Promise<void>;
  setApiUrl: (url: string) => Promise<void>;
  search: (query: string) => Promise<void>;
}

let searchId = 0; // descarta respostas antigas se o usuário buscar de novo

export const useAppStore = create<AppState>((set, get) => ({
  apiUrl: '',
  hydrated: false,
  results: INITIAL_TRACKS,
  loading: false,
  error: null,

  hydrate: async () => {
    const apiUrl = await getApiUrl();
    set({ apiUrl, hydrated: true });
  },

  setApiUrl: async (url) => {
    const clean = url.trim();
    set({ apiUrl: clean });
    await saveApiUrl(clean);
  },

  search: async (query) => {
    const q = query.trim();
    if (!q) return;

    const id = ++searchId;
    set({ loading: true, error: null });

    try {
      const tracks = await searchSongs(get().apiUrl, q);
      if (id !== searchId) return;
      set({ results: tracks, loading: false });
    } catch (e) {
      if (id !== searchId) return;
      set({
        loading: false,
        error: e instanceof Error ? e.message : 'Erro desconhecido',
      });
    }
  },
}));
