import AsyncStorage from '@react-native-async-storage/async-storage';
import { create } from 'zustand';
import { fetchTopAlbums, fetchTopSongs } from '../services/catalog';
import { loadAddons, saveAddons } from '../addons/storage';
import { runAddon } from '../addons/engine';
import { Addon } from '../addons/types';
import { searchYouTube } from '../services/youtube';
import { Album, Track } from '../types/track';

const KEY_STORAGE = 'music-player:youtube-key';

interface AppState {
  apiKey: string;
  hydrated: boolean;
  hydrate: () => Promise<void>;
  setApiKey: (key: string) => void;

  // Fontes extras (addons da comunidade). 'youtube' = fonte embutida (padrão).
  addons: Addon[];
  sourceId: string;
  setSource: (id: string) => void;
  /** Se replaceId existir, substitui; senão adiciona */
  saveAddon: (addon: Addon, replaceId?: string | null) => void;
  removeAddon: (id: string) => void;

  homeSongs: Track[];
  homeAlbums: Album[];
  homeLoading: boolean;
  homeError: string | null;
  loadHome: () => Promise<void>;

  results: Track[];
  loading: boolean;
  error: string | null;
  searched: boolean;
  search: (query: string) => Promise<void>;
}

let searchId = 0; // descarta respostas antigas se o usuário buscar de novo

export const useAppStore = create<AppState>((set, get) => ({
  apiKey: '',
  hydrated: false,

  hydrate: async () => {
    let apiKey = '';
    try {
      apiKey = (await AsyncStorage.getItem(KEY_STORAGE)) ?? '';
    } catch {
      /* sem persistência */
    }
    const addons = await loadAddons();
    set({ apiKey, addons, hydrated: true });
    void get().loadHome();
  },

  setApiKey: (key) => {
    const apiKey = key.trim();
    set({ apiKey });
    AsyncStorage.setItem(KEY_STORAGE, apiKey).catch(() => undefined);
  },

  addons: [],
  sourceId: 'youtube',

  setSource: (id) => {
    set({ sourceId: id, error: null, results: [], searched: false });
    const a = get().addons.find((x) => x.id === id);
    if (a && !a.search && a.list) void get().search(''); // fonte só de lista carrega sozinha
  },

  saveAddon: (addon, replaceId) => {
    const { addons } = get();
    let next: Addon[];
    let finalId: string;
    if (replaceId && addons.some((a) => a.id === replaceId)) {
      finalId = replaceId;
      next = addons.map((a) => (a.id === replaceId ? { ...addon, id: replaceId } : a));
    } else {
      const taken = new Set(addons.map((a) => a.id));
      let id = addon.id === 'youtube' ? 'youtube-2' : addon.id;
      let n = 2;
      while (taken.has(id) || id === 'youtube') id = `${addon.id}-${n++}`;
      finalId = id;
      next = [...addons, { ...addon, id }];
    }
    set({ addons: next });
    void saveAddons(next);
    get().setSource(finalId);
  },

  removeAddon: (id) => {
    const next = get().addons.filter((a) => a.id !== id);
    set({ addons: next });
    void saveAddons(next);
    if (get().sourceId === id) get().setSource('youtube');
  },

  homeSongs: [],
  homeAlbums: [],
  homeLoading: false,
  homeError: null,

  loadHome: async () => {
    set({ homeLoading: true, homeError: null });
    const [songs, albums] = await Promise.allSettled([fetchTopSongs(), fetchTopAlbums()]);
    set({
      homeSongs: songs.status === 'fulfilled' ? songs.value : [],
      homeAlbums: albums.status === 'fulfilled' ? albums.value : [],
      homeLoading: false,
      homeError:
        songs.status === 'rejected' && albums.status === 'rejected'
          ? 'Não consegui carregar a home (sem internet?). Puxe para baixo para tentar de novo.'
          : null,
    });
  },

  results: [],
  loading: false,
  error: null,
  searched: false,

  search: async (query) => {
    const q = query.trim();
    const addon = get().addons.find((a) => a.id === get().sourceId);
    if (!q && !(addon && addon.list)) return;
    const id = ++searchId;
    set({ loading: true, error: null, searched: true });
    try {
      const results = addon ? (await runAddon(addon, { query: q })).tracks : await searchYouTube(get().apiKey, q);
      if (id !== searchId) return;
      set({ results, loading: false });
    } catch (e) {
      if (id !== searchId) return;
      set({ results: [], loading: false, error: e instanceof Error ? e.message : 'Erro desconhecido' });
    }
  },
}));
