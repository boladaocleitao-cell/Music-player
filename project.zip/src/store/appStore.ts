import { create } from 'zustand';
import { INITIAL_TRACKS } from '../data/tracks';
import { runAddon } from '../services/addonEngine';
import { loadAddons, saveAddons } from '../services/addonStorage';
import { Addon } from '../types/addon';
import { Track } from '../types/track';

interface AppState {
  addons: Addon[];
  activeId: string | null;
  hydrated: boolean;
  results: Track[];
  loading: boolean;
  error: string | null;
  hydrate: () => Promise<void>;
  setActive: (id: string) => void;
  /** Se replaceId existir, substitui essa fonte; senão adiciona uma nova */
  saveAddon: (addon: Addon, replaceId?: string | null) => void;
  removeAddon: (id: string) => void;
  search: (query: string) => Promise<void>;
}

let searchId = 0; // descarta respostas antigas se o usuário buscar de novo

export const useAppStore = create<AppState>((set, get) => {
  const persist = () => {
    void saveAddons(get().addons, get().activeId);
  };

  // Fonte que só tem lista (sem busca) carrega sozinha ao ser escolhida
  const autoLoadIfList = () => {
    const a = get().addons.find((x) => x.id === get().activeId);
    if (a && !a.search && a.list) void get().search('');
  };

  return {
    addons: [],
    activeId: null,
    hydrated: false,
    results: INITIAL_TRACKS,
    loading: false,
    error: null,

    hydrate: async () => {
      const { addons, activeId } = await loadAddons();
      set({ addons, activeId, hydrated: true });
    },

    setActive: (id) => {
      set({ activeId: id, error: null });
      persist();
      autoLoadIfList();
    },

    saveAddon: (addon, replaceId) => {
      const { addons } = get();
      let next: Addon[];
      let finalId: string;

      if (replaceId && addons.some((a) => a.id === replaceId)) {
        finalId = replaceId; // mantém o id estável ao editar
        next = addons.map((a) => (a.id === replaceId ? { ...addon, id: replaceId } : a));
      } else {
        const taken = new Set(addons.map((a) => a.id));
        let id = addon.id;
        let n = 2;
        while (taken.has(id)) id = `${addon.id}-${n++}`;
        finalId = id;
        next = [...addons, { ...addon, id }];
      }

      set({ addons: next, activeId: finalId, error: null });
      persist();
      autoLoadIfList();
    },

    removeAddon: (id) => {
      const next = get().addons.filter((a) => a.id !== id);
      const activeId = get().activeId === id ? null : get().activeId;
      set({ addons: next, activeId });
      persist();
    },

    search: async (query) => {
      const addon = get().addons.find((a) => a.id === get().activeId);
      if (!addon) {
        set({ error: 'Nenhuma fonte ativa. Toque em ⚙ para escolher uma.' });
        return;
      }

      const q = query.trim();
      if (!q && !addon.list) return; // fonte só de busca e nada digitado

      const id = ++searchId;
      set({ loading: true, error: null });

      try {
        const result = await runAddon(addon, { query: q });
        if (id !== searchId) return;
        set({ results: result.tracks, loading: false });
      } catch (e) {
        if (id !== searchId) return;
        set({ loading: false, error: e instanceof Error ? e.message : 'Erro desconhecido' });
      }
    },
  };
});
