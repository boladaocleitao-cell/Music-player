// CloudGlass: roxo + vidro
export const colors = {
  background: '#0D0818',
  backgroundTop: '#2A1255', // brilho roxo no topo
  surface: 'rgba(255,255,255,0.07)',
  surfaceActive: 'rgba(167,139,250,0.20)',
  text: '#F5F2FF',
  textMuted: '#A99FC7',
  accent: '#A78BFA', // roxo principal
  accentStrong: '#7C3AED',
  onAccent: '#13062B',
  track: 'rgba(255,255,255,0.18)',
  glassBorder: 'rgba(255,255,255,0.22)',
  glassFill: 'rgba(40,20,80,0.35)',
  danger: '#FF6B81',
  ok: '#5EEAD4',
};

export const spacing = { xs: 4, sm: 8, md: 16, lg: 24, xl: 32 };

export const typography = {
  hero: { fontSize: 34, fontWeight: '800' as const },
  title: { fontSize: 18, fontWeight: '700' as const },
  body: { fontSize: 15, fontWeight: '400' as const },
  caption: { fontSize: 12, fontWeight: '400' as const },
};
