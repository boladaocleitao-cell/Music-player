export const colors = {
  background: '#0B0B0F',
  surface: '#16161D',
  surfaceActive: '#1F1F2A',
  text: '#F2F2F5',
  textMuted: '#8A8A99',
  accent: '#FFFFFF',
  track: '#2A2A36',
};

export const spacing = { xs: 4, sm: 8, md: 16, lg: 24, xl: 32 };

export const typography = {
  title: { fontSize: 18, fontWeight: '600' as const },
  body: { fontSize: 15, fontWeight: '400' as const },
  caption: { fontSize: 12, fontWeight: '400' as const },
};
