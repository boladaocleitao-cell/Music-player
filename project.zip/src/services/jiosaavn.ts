import { Track } from '../types/track';

type DownloadLink = { quality: string; url: string };
type ApiSong = {
  id: string;
  name: string;
  duration: number | null;
  artists?: { primary?: { name: string }[]; all?: { name: string }[] };
  image?: DownloadLink[];
  downloadUrl?: DownloadLink[];
};

// Escolhe a qualidade pedida; se não existir, usa a mais próxima disponível
function pickAudio(links: DownloadLink[] | undefined, preferred: string): string | null {
  if (!links || links.length === 0) return null;
  const exact = links.find((l) => l.quality === preferred);
  return (exact ?? links[links.length - 1]).url;
}

function toHttps(url: string): string {
  return url.replace(/^http:\/\//, 'https://');
}

function decodeEntities(text: string): string {
  // a API devolve nomes com entidades HTML, ex.: "Rock &amp; Roll"
  return text
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .replace(/&#039;/g, "'")
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>');
}

export function songToTrack(song: ApiSong, quality = '160kbps'): Track | null {
  const audio = pickAudio(song.downloadUrl, quality);
  if (!audio) return null;

  const artists = song.artists?.primary?.length ? song.artists.primary : song.artists?.all ?? [];
  const cover = song.image?.length ? song.image[song.image.length - 1].url : undefined;

  return {
    id: song.id,
    title: decodeEntities(song.name),
    artist: artists.map((a) => decodeEntities(a.name)).join(', ') || 'Desconhecido',
    uri: toHttps(audio),
    source: 'remote',
    artwork: cover ? toHttps(cover) : undefined,
    duration: song.duration ?? undefined,
  };
}

export async function searchSongs(
  baseUrl: string,
  query: string,
  limit = 20,
  quality = '160kbps'
): Promise<Track[]> {
  const base = baseUrl.trim().replace(/\/+$/, '');
  if (!base) throw new Error('Informe a URL da API');
  if (!/^https:\/\//i.test(base)) throw new Error('A URL precisa começar com https://');

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15000);

  try {
    const url = `${base}/api/search/songs?query=${encodeURIComponent(query)}&limit=${limit}`;
    const res = await fetch(url, { signal: controller.signal });
    if (!res.ok) throw new Error(`Erro HTTP ${res.status}`);

    const json = await res.json();
    const results: ApiSong[] = json?.data?.results ?? [];
    const tracks = results
      .map((s) => songToTrack(s, quality))
      .filter((t): t is Track => t !== null);

    if (tracks.length === 0) throw new Error('Nenhuma música encontrada');
    return tracks;
  } catch (e) {
    if (e instanceof Error && e.name === 'AbortError') {
      throw new Error('Tempo esgotado. Verifique a URL da API');
    }
    throw e;
  } finally {
    clearTimeout(timeout);
  }
}
