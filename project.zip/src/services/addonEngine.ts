import { Addon, AddonRequest, Path } from '../types/addon';
import { Track } from '../types/track';

// ---------------------------------------------------------------
// Leitor de caminhos: "a.b[0].c", "a[-1]", "a[*].name", "a[quality=160kbps].url"
// ---------------------------------------------------------------

type Token =
  | { t: 'key'; k: string }
  | { t: 'index'; i: number }
  | { t: 'find'; k: string; v: string }
  | { t: 'all' };

const tokenCache = new Map<string, Token[]>();

function tokenize(path: string): Token[] {
  const cached = tokenCache.get(path);
  if (cached) return cached;

  const tokens: Token[] = [];
  const re = /([^.[\]]+)|\[([^\]]*)\]/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(path)) !== null) {
    if (m[1] !== undefined) {
      tokens.push({ t: 'key', k: m[1].trim() });
    } else {
      const inner = (m[2] ?? '').trim();
      if (inner === '*') tokens.push({ t: 'all' });
      else if (/^-?\d+$/.test(inner)) tokens.push({ t: 'index', i: Number(inner) });
      else if (inner.includes('=')) {
        const [k, ...rest] = inner.split('=');
        tokens.push({ t: 'find', k: k.trim(), v: rest.join('=').trim() });
      }
    }
  }
  tokenCache.set(path, tokens);
  return tokens;
}

function resolve(cur: unknown, tokens: Token[], pos: number): unknown {
  if (pos >= tokens.length) return cur;
  if (cur === null || cur === undefined) return undefined;
  const tk = tokens[pos];

  switch (tk.t) {
    case 'key':
      if (typeof cur !== 'object') return undefined;
      return resolve((cur as Record<string, unknown>)[tk.k], tokens, pos + 1);
    case 'index': {
      if (!Array.isArray(cur)) return undefined;
      const i = tk.i < 0 ? cur.length + tk.i : tk.i;
      return resolve(cur[i], tokens, pos + 1);
    }
    case 'find': {
      if (!Array.isArray(cur)) return undefined;
      const el = cur.find(
        (e) => e !== null && typeof e === 'object' && String((e as Record<string, unknown>)[tk.k]) === tk.v
      );
      return resolve(el, tokens, pos + 1);
    }
    case 'all': {
      if (!Array.isArray(cur)) return undefined;
      return cur
        .map((e) => resolve(e, tokens, pos + 1))
        .filter((v) => v !== undefined && v !== null);
    }
  }
}

export function getPath(data: unknown, path: string | undefined): unknown {
  if (!path || !path.trim()) return data;
  return resolve(data, tokenize(path.trim()), 0);
}

// ---------------------------------------------------------------
// Conversão de valores
// ---------------------------------------------------------------

function toText(v: unknown): string | undefined {
  if (typeof v === 'string') {
    const t = v.trim();
    return t || undefined;
  }
  if (typeof v === 'number' && Number.isFinite(v)) return String(v);
  if (Array.isArray(v)) {
    const parts = v.map(toText).filter((x): x is string => !!x);
    return parts.length ? parts.join(', ') : undefined;
  }
  return undefined;
}

function pickText(item: unknown, paths: Path | undefined): string | undefined {
  if (!paths) return undefined;
  const list = Array.isArray(paths) ? paths : [paths];
  for (const p of list) {
    const t = toText(getPath(item, p));
    if (t) return t;
  }
  return undefined;
}

function toHttps(url: string): string {
  return url.replace(/^http:\/\//i, 'https://');
}

function withPrefix(url: string, prefix?: string): string {
  if (!prefix || /^https?:\/\//i.test(url)) return url;
  return prefix + url.replace(/^\/+/, '');
}

function decodeEntities(text: string): string {
  return text
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .replace(/&#039;/g, "'")
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>');
}

// ---------------------------------------------------------------
// Validação do addon (texto colado pelo usuário)
// ---------------------------------------------------------------

function slug(text: string): string {
  return (
    text
      .toLowerCase()
      .normalize('NFD')
      .replace(/[̀-ͯ]/g, '')
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '') || 'addon'
  );
}

export function parseAddon(text: string): Addon {
  // o teclado do iPhone troca " por aspas curvas; desfazemos isso
  const clean = text
    .replace(/[“”]/g, '"')
    .replace(/[‘’]/g, "'")
    .trim();

  let raw: unknown;
  try {
    raw = JSON.parse(clean);
  } catch (e) {
    throw new Error('JSON inválido: ' + (e instanceof Error ? e.message : String(e)));
  }

  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) {
    throw new Error('O addon precisa ser um objeto { ... }');
  }
  const obj = raw as Record<string, unknown>;

  const name = typeof obj.name === 'string' ? obj.name.trim() : '';
  if (!name) throw new Error('Falta o campo "name"');

  if (obj.baseUrl !== undefined && typeof obj.baseUrl !== 'string') {
    throw new Error('"baseUrl" precisa ser um texto');
  }
  if (!obj.search && !obj.list) throw new Error('Defina "search" (com {query}) e/ou "list"');
  for (const key of ['search', 'list'] as const) {
    const req = obj[key] as Record<string, unknown> | undefined;
    if (!req) continue;
    if (typeof req !== 'object' || typeof req.url !== 'string') {
      throw new Error(`"${key}.url" é obrigatório (texto)`);
    }
    if (req.listPath !== undefined && typeof req.listPath !== 'string') {
      throw new Error(`"${key}.listPath" precisa ser um texto, ex.: "data.results"`);
    }
    if (req.method !== undefined && req.method !== 'GET' && req.method !== 'POST') {
      throw new Error(`"${key}.method" precisa ser "GET" ou "POST"`);
    }
    if (req.headers !== undefined) {
      const h = req.headers;
      const ok =
        h !== null &&
        typeof h === 'object' &&
        !Array.isArray(h) &&
        Object.values(h as object).every((v) => typeof v === 'string');
      if (!ok) throw new Error(`"${key}.headers" precisa ser { "Nome": "valor" } com textos`);
    }
  }

  const map = obj.map as Record<string, unknown> | undefined;
  if (!map || typeof map !== 'object' || !map.title || !map.audio) {
    throw new Error('Falta "map.title" e/ou "map.audio"');
  }
  for (const key of ['id', 'title', 'artist', 'audio', 'artwork', 'duration']) {
    const v = map[key];
    if (v === undefined || v === null || v === '') continue;
    const ok = typeof v === 'string' || (Array.isArray(v) && v.every((x) => typeof x === 'string'));
    if (!ok) throw new Error(`"map.${key}" precisa ser um caminho (texto) ou uma lista de caminhos`);
  }

  const id = typeof obj.id === 'string' && obj.id.trim() ? slug(obj.id) : slug(name);
  return { ...(obj as object), id, name } as Addon;
}

// ---------------------------------------------------------------
// Execução
// ---------------------------------------------------------------

const LIST_KEYS = ['tracks', 'songs', 'musicas', 'musics', 'items', 'results', 'playlist', 'data'];

function autoFindList(json: unknown): unknown[] | null {
  if (Array.isArray(json)) return json;
  if (!json || typeof json !== 'object') return null;
  const obj = json as Record<string, unknown>;

  for (const k of LIST_KEYS) if (Array.isArray(obj[k])) return obj[k] as unknown[];
  for (const k of LIST_KEYS) {
    const inner = obj[k];
    if (inner && typeof inner === 'object' && !Array.isArray(inner)) {
      for (const k2 of LIST_KEYS) {
        const v = (inner as Record<string, unknown>)[k2];
        if (Array.isArray(v)) return v;
      }
    }
  }
  return null;
}

function fill(tpl: string, vars: Record<string, string>, encodeQuery: (s: string) => string): string {
  return tpl.replace(/\{(\w+)\}/g, (match, k: string) => {
    // variável desconhecida fica como está (ex.: {id} dentro de um corpo GraphQL)
    if (!(k in vars)) return match;
    return k === 'query' ? encodeQuery(vars[k]) : vars[k];
  });
}

function itemToTrack(item: unknown, addon: Addon, index: number): Track | null {
  const m = addon.map;
  const audioRaw = pickText(item, m.audio);
  if (!audioRaw) return null;

  const art = pickText(item, m.artwork);
  const durText = pickText(item, m.duration);
  let dur = durText !== undefined ? Number(durText) : NaN;
  // APIs que informam milissegundos (ex.: 204000): nenhuma música tem 10 h
  if (Number.isFinite(dur) && dur > 36000) dur = dur / 1000;

  return {
    id: pickText(item, m.id) ?? `${addon.id}-${index}`,
    title: decodeEntities(pickText(item, m.title) ?? `Faixa ${index + 1}`),
    artist: decodeEntities(pickText(item, m.artist) ?? 'Desconhecido'),
    uri: toHttps(withPrefix(audioRaw, addon.audioPrefix)),
    source: 'remote',
    artwork: art ? toHttps(withPrefix(art, addon.artworkPrefix)) : undefined,
    duration: Number.isFinite(dur) && dur > 0 ? dur : undefined,
  };
}

export interface RunResult {
  tracks: Track[];
  total: number; // itens encontrados na resposta
  sample: string; // 1º item bruto, para o usuário ajustar o mapeamento
}

export async function runAddon(
  addon: Addon,
  input: { query?: string; page?: number } = {}
): Promise<RunResult> {
  const q = (input.query ?? '').trim();

  let req: AddonRequest | undefined;
  let usedList = false;
  if (q && addon.search) req = addon.search;
  else if (addon.list) {
    req = addon.list;
    usedList = true;
  } else if (addon.search) {
    throw new Error('Digite algo para buscar');
  }
  if (!req) throw new Error('Esta fonte não tem "search" nem "list"');

  let base = (addon.baseUrl ?? '').trim().replace(/\/+$/, '');
  if (/^https?:$/i.test(base)) base = ''; // só "https://" = modelo em branco, não preenchido
  const usesBase = req.url.includes('{baseUrl}') || req.url.startsWith('/');
  if (usesBase && !base) throw new Error('Preencha o "baseUrl" da fonte (toque em Editar)');

  const vars = { baseUrl: base, query: q, page: String(input.page ?? 0), limit: '20' };
  let url = fill(req.url, vars, encodeURIComponent);
  if (url.startsWith('/')) url = base + url;
  if (!/^https:\/\//i.test(url)) {
    throw new Error(`A URL precisa começar com https:// (ficou: ${url.slice(0, 60) || 'vazia'})`);
  }

  const method = req.method ?? 'GET';
  const headers: Record<string, string> = {};
  for (const [k, v] of Object.entries(req.headers ?? {})) headers[k] = fill(v, vars, (s) => s);
  const body =
    method === 'POST' && req.body
      ? fill(req.body, vars, (s) => JSON.stringify(s).slice(1, -1))
      : undefined;

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15000);

  let json: unknown;
  try {
    const res = await fetch(url, { method, headers, body, signal: controller.signal });
    if (!res.ok) throw new Error(`Erro HTTP ${res.status}`);
    const text = await res.text();
    try {
      json = JSON.parse(text);
    } catch {
      throw new Error('A resposta não é um JSON válido');
    }
  } catch (e) {
    if (e instanceof Error && e.name === 'AbortError') {
      throw new Error('Tempo esgotado. Verifique a URL');
    }
    throw e;
  } finally {
    clearTimeout(timeout);
  }

  const rawList = req.listPath ? getPath(json, req.listPath) : autoFindList(json);
  if (!Array.isArray(rawList)) {
    const keys =
      json && typeof json === 'object' && !Array.isArray(json)
        ? Object.keys(json as object).slice(0, 8).join(', ')
        : typeof json;
    throw new Error(
      req.listPath
        ? `Não achei uma lista em "${req.listPath}". Chaves no topo da resposta: ${keys}`
        : `Não achei a lista de músicas. Defina "listPath". Chaves no topo da resposta: ${keys}`
    );
  }

  let tracks = rawList
    .map((item, i) => itemToTrack(item, addon, i))
    .filter((t): t is Track => t !== null);

  // ids repetidos quebram a lista; garante unicidade
  const seen = new Map<string, number>();
  tracks = tracks.map((t) => {
    const n = seen.get(t.id) ?? 0;
    seen.set(t.id, n + 1);
    return n === 0 ? t : { ...t, id: `${t.id}#${n}` };
  });

  // fonte só com lista + usuário digitou algo: filtra localmente
  if (usedList && q) {
    const needle = q.toLowerCase();
    const playable = tracks.length;
    tracks = tracks.filter(
      (t) => t.title.toLowerCase().includes(needle) || t.artist.toLowerCase().includes(needle)
    );
    if (tracks.length === 0 && playable > 0) {
      throw new Error(`A lista tem ${playable} músicas, mas nenhuma combina com "${q}"`);
    }
  }

  if (tracks.length === 0) {
    throw new Error(
      rawList.length === 0
        ? 'A lista veio vazia'
        : 'Achei itens, mas nenhum com link de áudio. Confira "map.audio"'
    );
  }

  const first = rawList[0];
  const sample = (JSON.stringify(first, null, 1) ?? '').slice(0, 700);
  return { tracks, total: rawList.length, sample };
}
