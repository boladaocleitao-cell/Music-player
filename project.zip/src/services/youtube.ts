import { Track } from '../types/track';

// Busca pela YouTube Data API v3 (oficial, com a SUA chave).
// Custo de cota: search = 100 unidades, videos = 1 (limite padrão: 10.000/dia).

const API = 'https://www.googleapis.com/youtube/v3';

/** Erro que não adianta tentar de novo nem pular de faixa (chave ausente/inválida, cota) */
export class YouTubeFatalError extends Error {
  fatal = true;
  constructor(message: string) {
    super(message);
    this.name = 'YouTubeFatalError';
  }
}

/** Tira o ruído de títulos do YouTube: "(Official Video)", "[HD]", "| Lyrics"… */
export function cleanTitle(t: string): string {
  return t
    .replace(/[\(\[](?:official\s*)?(?:music\s*)?(?:video|audio|lyric(?:s)?(?:\s*video)?|visuali[sz]er|hd|4k|clipe(?: oficial)?|áudio oficial|vídeo oficial)[^\)\]]*[\)\]]/gi, '')
    .replace(/\s*[|\-–]\s*(?:official|lyrics?|clipe).*$/i, '')
    .replace(/\s{2,}/g, ' ')
    .trim();
}

function decodeEntities(t: string): string {
  return t
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&#039;/g, "'")
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>');
}

/** "PT3M25S" -> 205 */
export function parseIsoDuration(iso: string | undefined): number | undefined {
  if (!iso) return undefined;
  const m = /^P(?:(\d+)D)?T?(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?$/.exec(iso);
  if (!m) return undefined;
  const [d, h, mi, s] = [m[1], m[2], m[3], m[4]].map((x) => Number(x ?? 0));
  const total = d * 86400 + h * 3600 + mi * 60 + s;
  return total > 0 ? total : undefined;
}

interface ApiError {
  error?: { code?: number; message?: string; errors?: { reason?: string }[] };
}

function explain(status: number, body: ApiError | null): Error {
  const reason = body?.error?.errors?.[0]?.reason;
  if (reason === 'quotaExceeded') {
    return new YouTubeFatalError('Cota diária da API do YouTube esgotada. Volta amanhã (ou use outra chave).');
  }
  if (reason === 'keyInvalid' || reason === 'API_KEY_INVALID' || body?.error?.message?.includes('API key not valid')) {
    return new YouTubeFatalError('Chave da API inválida. Confira a chave em ⚙.');
  }
  if (reason === 'accessNotConfigured' || reason === 'forbidden' || status === 403) {
    return new YouTubeFatalError(
      `A chave foi recusada (${reason ?? 'HTTP 403'}). Ative a "YouTube Data API v3" no projeto e confira as restrições da chave.`
    );
  }
  return new Error(`Erro do YouTube (HTTP ${status}${body?.error?.message ? ': ' + body.error.message : ''})`);
}

async function getJson<T>(url: string): Promise<T> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15000);
  try {
    const res = await fetch(url, { signal: controller.signal });
    const text = await res.text();
    let body: unknown = null;
    try {
      body = JSON.parse(text);
    } catch {
      /* corpo não é JSON */
    }
    if (!res.ok) throw explain(res.status, body as ApiError | null);
    return body as T;
  } catch (e) {
    if (e instanceof Error && e.name === 'AbortError') throw new Error('Tempo esgotado ao falar com o YouTube');
    throw e;
  } finally {
    clearTimeout(timeout);
  }
}

interface SearchResponse {
  items?: {
    id?: { videoId?: string };
    snippet?: {
      title?: string;
      channelTitle?: string;
      thumbnails?: Record<string, { url?: string }>;
    };
  }[];
}
interface VideosResponse {
  items?: { id: string; contentDetails?: { duration?: string } }[];
}

function requireKey(apiKey: string): string {
  const key = apiKey.trim();
  if (!key) throw new YouTubeFatalError('Falta a chave da API do YouTube. Toque em ⚙ e cole a chave.');
  return key;
}

async function rawSearch(key: string, query: string, maxResults: number) {
  const url =
    `${API}/search?part=snippet&type=video&videoEmbeddable=true&videoCategoryId=10` +
    `&maxResults=${maxResults}&q=${encodeURIComponent(query)}&key=${encodeURIComponent(key)}`;
  const data = await getJson<SearchResponse>(url);
  return (data.items ?? []).filter((i) => i.id?.videoId);
}

type Item = Awaited<ReturnType<typeof rawSearch>>[number];

function toTrack(i: Item, durations?: Map<string, number>): Track {
  const videoId = i.id!.videoId!;
  const th = i.snippet?.thumbnails;
  return {
    id: `yt-${videoId}`,
    videoId,
    title: cleanTitle(decodeEntities(i.snippet?.title ?? 'Sem título')) || 'Sem título',
    artist: decodeEntities((i.snippet?.channelTitle ?? 'YouTube').replace(/ - Topic$/, '')),
    uri: `https://www.youtube.com/watch?v=${videoId}`,
    source: 'youtube',
    artwork: th?.medium?.url ?? th?.default?.url,
    duration: durations?.get(videoId),
  };
}

/** Busca para a aba "Buscar": tudo que o YouTube achar aparece (e toca ao clicar) */
export async function searchYouTube(apiKey: string, query: string): Promise<Track[]> {
  const key = requireKey(apiKey);
  const items = await rawSearch(key, query, 20);
  if (items.length === 0) throw new Error(`Nada encontrado no YouTube para "${query}"`);

  const durations = new Map<string, number>();
  try {
    const ids = items.map((i) => i.id!.videoId!).join(',');
    const v = await getJson<VideosResponse>(
      `${API}/videos?part=contentDetails&id=${ids}&key=${encodeURIComponent(key)}`
    );
    for (const it of v.items ?? []) {
      const d = parseIsoDuration(it.contentDetails?.duration);
      if (d) durations.set(it.id, d);
    }
  } catch (e) {
    if (e instanceof YouTubeFatalError) throw e;
  }

  const seen = new Set<string>();
  return items
    .filter((i) => (seen.has(i.id!.videoId!) ? false : (seen.add(i.id!.videoId!), true)))
    .map((i) => toTrack(i, durations));
}

/**
 * Auto-busca: acha o vídeo de uma música do catálogo (artista + título).
 * Se a duração do catálogo for conhecida, escolhe o vídeo com duração parecida
 * (evita versão ao vivo, remix ou vídeo de 1 hora).
 */
export async function findVideoId(apiKey: string, artist: string, title: string, duration?: number): Promise<string> {
  const key = requireKey(apiKey);
  const items = await rawSearch(key, `${artist} - ${title} official audio`, 8);
  if (items.length === 0) throw new Error(`Não achei "${title}" no YouTube`);

  const needle = title.toLowerCase();
  const ids = items.map((i) => i.id!.videoId!);
  const titleOf = (i: Item) => decodeEntities(i.snippet?.title ?? '').toLowerCase();

  let durations = new Map<string, number>();
  if (duration && duration > 0) {
    try {
      const v = await getJson<VideosResponse>(
        `${API}/videos?part=contentDetails&id=${ids.join(',')}&key=${encodeURIComponent(key)}`
      );
      for (const it of v.items ?? []) {
        const d = parseIsoDuration(it.contentDetails?.duration);
        if (d) durations.set(it.id, d);
      }
    } catch (e) {
      if (e instanceof YouTubeFatalError) throw e;
      durations = new Map();
    }
  }

  const score = (i: Item): number => {
    let sc = 0;
    if (titleOf(i).includes(needle)) sc += 2;
    const d = durations.get(i.id!.videoId!);
    if (duration && d) {
      const diff = Math.abs(d - duration);
      if (diff <= 4) sc += 4;
      else if (diff <= 12) sc += 2;
      else if (diff > 60) sc -= 3;
    }
    if (/\b(live|ao vivo|cover|karaoke|reaction|remix|sped up|slowed)\b/i.test(titleOf(i)) && !/\b(live|remix|cover)\b/i.test(needle)) sc -= 2;
    return sc;
  };
  // empate: mantém a ordem de relevância do YouTube
  return items.reduce((best, i) => (score(i) > score(best) ? i : best), items[0]).id!.videoId!;
}
