import AsyncStorage from '@react-native-async-storage/async-storage';

const API_URL_KEY = 'music-player:api-url';

export async function getApiUrl(): Promise<string> {
  try {
    return (await AsyncStorage.getItem(API_URL_KEY)) ?? '';
  } catch {
    return '';
  }
}

export async function setApiUrl(url: string): Promise<void> {
  try {
    await AsyncStorage.setItem(API_URL_KEY, url.trim());
  } catch {
    // sem persistência, o app continua funcionando
  }
}
