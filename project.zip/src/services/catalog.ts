import { Album, Track } from '../types/track';

// Catálogo da home (sem addon e sem chave): feeds públicos da Apple.
// Só traz METADADOS (nome, artista, capa). O áudio vem do YouTube ao clicar.
const COUNTRY = 'br';
const RSS = `https://rss.applemarketingtools.com/api/v2/${COUNTRY}/music/most-played`;

async function getJson(url: string): Promise<any> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 12000);
  try {
    const res = await fetch(url, { signal: controller.signal });
    if (!res.ok) throw new Error(`Erro HTTP ${res.status}`);
    return await res.json();
  } finally {
    clearTimeout(timeout);
  }
}

const big = (url?: string) => (url ? url.replace(/\d+x\d+(bb)?\./, '400x400bb.') : undefined);

function song(id: string, title: string, artist: string, artwork?: string, duration?: number): Track {
  return { id: `cat-${id}`, title, artist, uri: '', source: 'youtube', artwork: big(artwork), duration };
}

export async function fetchTopSongs(): Promise<Track[]> {
  const j = await getJson(`${RSS}/50/songs.json`);
  const list: any[] = j?.feed?.results ?? [];
  return list.map((r) => song(String(r.id), String(r.name), String(r.artistName), r.artworkUrl100));
}

export async function fetchTopAlbums(): Promise<Album[]> {
  const j = await getJson(`${RSS}/25/albums.json`);
  const list: any[] = j?.feed?.results ?? [];
  return list.map((r) => ({
    id: String(r.id),
    name: String(r.name),
    artist: String(r.artistName),
    artwork: big(r.artworkUrl100),
  }));
}

export async function fetchAlbumTracks(album: Album): Promise<Track[]> {
  const j = await getJson(`https://itunes.apple.com/lookup?id=${encodeURIComponent(album.id)}&entity=song&country=${COUNTRY}`);
  const rows: any[] = (j?.results ?? []).filter((r: any) => r.wrapperType === 'track' && r.trackName);
  rows.sort((a, b) => (a.trackNumber ?? 0) - (b.trackNumber ?? 0));
  return rows.map((r) =>
    song(
      String(r.trackId),
      String(r.trackName),
      String(r.artistName ?? album.artist),
      r.artworkUrl100 ?? album.artwork,
      r.trackTimeMillis ? r.trackTimeMillis / 1000 : undefined
    )
  );
}
