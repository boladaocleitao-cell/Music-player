import AsyncStorage from '@react-native-async-storage/async-storage';
import { Track } from '../types/track';
import { findVideoId } from './youtube';

// Guarda "artista|título" -> videoId para não gastar cota da API tocando a mesma música de novo.
const KEY = 'music-player:yt-cache';
let cache: Record<string, string> | null = null;

async function load(): Promise<Record<string, string>> {
  if (cache) return cache;
  try {
    const raw = await AsyncStorage.getItem(KEY);
    cache = raw ? (JSON.parse(raw) as Record<string, string>) : {};
  } catch {
    cache = {};
  }
  return cache;
}

// Duração oficial da faixa (iTunes lookup: grátis, não gasta cota do YouTube)
async function catalogDuration(track: Track): Promise<number | undefined> {
  if (track.duration) return track.duration;
  const m = /^cat-(\d+)$/.exec(track.id);
  if (!m) return undefined;
  try {
    const res = await fetch(`https://itunes.apple.com/lookup?id=${m[1]}&country=br`);
    if (!res.ok) return undefined;
    const j = (await res.json()) as { results?: { trackTimeMillis?: number }[] };
    const ms = j.results?.[0]?.trackTimeMillis;
    return ms ? ms / 1000 : undefined;
  } catch {
    return undefined;
  }
}

export async function resolveVideoId(apiKey: string, track: Track): Promise<string> {
  if (track.videoId) return track.videoId;
  const k = `${track.artist}|${track.title}`.toLowerCase();
  const c = await load();
  if (c[k]) return c[k];
  const id = await findVideoId(apiKey, track.artist, track.title, await catalogDuration(track));
  c[k] = id;
  try {
    await AsyncStorage.setItem(KEY, JSON.stringify(c));
  } catch {
    /* sem persistência */
  }
  return id;
}
