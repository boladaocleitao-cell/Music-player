import { AudioStatus, createAudioPlayer, setAudioModeAsync } from 'expo-audio';
import type { AudioPlayer } from 'expo-audio';
import { Track } from '../types/track';

export interface EngineState {
  queue: Track[];
  index: number;
  isPlaying: boolean;
  isBuffering: boolean;
  isLoaded: boolean;
  position: number; // segundos
  duration: number; // segundos
  error: string | null;
}

type Listener = () => void;

/** Controle do player oficial do YouTube (WebView), registrado por components/YouTubePlayer */
export interface YouTubeController {
  load(videoId: string, autoplay: boolean): void;
  play(): void;
  pause(): void;
  seekTo(seconds: number): void;
  stop(): void;
}

/** Estado enviado pelo player do YouTube */
export interface YouTubeStatus {
  playing?: boolean;
  buffering?: boolean;
  loaded?: boolean;
  position?: number;
  duration?: number;
  ended?: boolean;
  error?: string;
}

const INITIAL_STATE: EngineState = {
  queue: [],
  index: -1,
  isPlaying: false,
  isBuffering: false,
  isLoaded: false,
  position: 0,
  duration: 0,
  error: null,
};

// Se passou mais que isso, "voltar" reinicia a faixa em vez de ir para a anterior
const RESTART_THRESHOLD_SECONDS = 3;

class AudioEngine {
  private player: AudioPlayer | null = null;
  private subscription: { remove: () => void } | null = null;
  private initPromise: Promise<void> | null = null;
  private listeners = new Set<Listener>();
  private state: EngineState = INITIAL_STATE;

  private hasSource = false;
  private lockScreenActive = false;
  private finishHandled = false;
  private errorHandled = false;
  private consecutiveErrors = 0;

  private resolver: ((track: Track) => Promise<string>) | null = null;
  private yt: YouTubeController | null = null;
  private ytPending: { videoId: string; autoplay: boolean } | null = null;

  private get isYT(): boolean {
    return this.state.queue[this.state.index]?.source === 'youtube';
  }

  /** Descobre o videoId de uma faixa do catálogo (auto-busca no YouTube) */
  setResolver(fn: (track: Track) => Promise<string>) {
    this.resolver = fn;
  }

  /** Chamado pelo componente do player do YouTube ao montar/desmontar */
  setYouTubeController(c: YouTubeController | null) {
    this.yt = c;
    if (c && this.ytPending) {
      const p = this.ytPending;
      this.ytPending = null;
      c.load(p.videoId, p.autoplay);
    }
  }

  /** Chamado pelo player do YouTube a cada mudança de estado */
  onYouTubeStatus = (s: YouTubeStatus) => {
    if (!this.isYT) return; // evento atrasado de uma faixa que já saiu
    const current = this.state.queue[this.state.index];
    const partial: Partial<EngineState> = {};
    if (s.playing !== undefined) partial.isPlaying = s.playing;
    if (s.buffering !== undefined) partial.isBuffering = s.buffering;
    if (s.loaded !== undefined) partial.isLoaded = s.loaded;
    if (s.position !== undefined) partial.position = s.position;
    if (s.duration !== undefined && s.duration > 0) partial.duration = s.duration;
    else if (!this.state.duration && current?.duration) partial.duration = current.duration;
    this.patch(partial);

    if (s.playing) this.consecutiveErrors = 0;

    if (s.error && !this.errorHandled) {
      this.errorHandled = true;
      this.handleError(s.error);
      return;
    }
    if (s.ended && !this.finishHandled) {
      this.finishHandled = true;
      void this.next(true);
    }
  };

  // ---------- estado (compatível com useSyncExternalStore) ----------

  getState = (): EngineState => this.state;

  subscribe = (listener: Listener): (() => void) => {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  };

  private patch(partial: Partial<EngineState>) {
    this.state = { ...this.state, ...partial };
    this.listeners.forEach((l) => l());
  }

  // ---------- inicialização ----------

  init(): Promise<void> {
    if (!this.initPromise) {
      this.initPromise = (async () => {
        await setAudioModeAsync({
          playsInSilentMode: true,
          shouldPlayInBackground: true,
          // 'doNotMix' é obrigatório para os controles da tela de bloqueio
          interruptionMode: 'doNotMix',
        });
        // Um único player para o app todo: troca a fonte com replace()
        // e mantém a tela de bloqueio sempre ligada ao mesmo player.
        this.player = createAudioPlayer(null, { updateInterval: 500 });
        this.subscription = this.player.addListener('playbackStatusUpdate', this.onStatus);
      })();
    }
    return this.initPromise;
  }

  // ---------- eventos do player ----------

  private onStatus = (status: AudioStatus) => {
    if (this.isYT) return;
    const current = this.state.queue[this.state.index];

    this.patch({
      isPlaying: status.playing,
      isBuffering: status.isBuffering,
      isLoaded: status.isLoaded,
      position: status.currentTime,
      duration: status.duration > 0 ? status.duration : current?.duration ?? 0,
    });

    if (status.playing) this.consecutiveErrors = 0;

    if (status.error && !this.errorHandled) {
      this.errorHandled = true;
      this.handleError(String(status.error));
      return;
    }

    if (status.didJustFinish && !this.finishHandled) {
      this.finishHandled = true;
      void this.next(true);
    }
  };

  private handleError(message: string) {
    this.patch({ error: message, isPlaying: false });
    this.consecutiveErrors += 1;
    // Pula a faixa com problema, mas desiste se a fila inteira falhou em sequência
    if (this.consecutiveErrors < this.state.queue.length) {
      void this.next(true);
    }
  }

  // ---------- carregar e tocar ----------

  private async loadIndex(index: number, autoplay = true) {
    await this.init();
    const track = this.state.queue[index];
    const player = this.player;
    if (!track || !player) return;

    this.finishHandled = false;
    this.errorHandled = false;
    this.patch({
      index,
      position: 0,
      duration: track.duration ?? 0,
      isLoaded: false,
      error: null,
    });

    if (track.source === 'youtube') {
      // áudio nativo para; quem toca é o player oficial do YouTube
      player.pause();
      this.hasSource = true;
      this.patch({ isPlaying: false, isBuffering: autoplay });

      let videoId = track.videoId;
      if (!videoId) {
        // música do catálogo: auto-busca no YouTube só agora, ao clicar
        try {
          if (!this.resolver) throw new Error('Resolvedor do YouTube não configurado');
          videoId = await this.resolver(track);
        } catch (e) {
          if (this.state.index !== index || this.state.queue[index]?.id !== track.id) return;
          const fatal = (e as { fatal?: boolean }).fatal === true;
          const message = e instanceof Error ? e.message : String(e);
          this.errorHandled = true;
          this.patch({ error: message, isPlaying: false, isBuffering: false });
          if (!fatal) this.handleError(message);
          return;
        }
        // o usuário já escolheu outra faixa enquanto buscávamos
        if (this.state.index !== index || this.state.queue[index]?.id !== track.id) return;
        const queue = this.state.queue.slice();
        queue[index] = { ...track, videoId };
        this.patch({ queue });
      }

      if (this.yt) this.yt.load(videoId, autoplay);
      else this.ytPending = { videoId, autoplay };
      return;
    }

    this.ytPending = null;
    this.yt?.stop();
    const source = typeof track.uri === 'number' ? track.uri : { uri: track.uri };
    player.replace(source);
    this.hasSource = true;
    if (autoplay) player.play();

    this.updateLockScreen(track);
  }

  private updateLockScreen(track: Track) {
    const player = this.player;
    if (!player) return;
    const metadata = {
      title: track.title,
      artist: track.artist,
      artworkUrl: track.artwork,
    };
    if (!this.lockScreenActive) {
      player.setActiveForLockScreen(true, metadata);
      this.lockScreenActive = true;
    } else {
      player.updateLockScreenMetadata(metadata);
    }
  }

  // ---------- API pública ----------

  /** Define a fila e começa a tocar em startIndex */
  async setQueue(tracks: Track[], startIndex = 0, autoplay = true) {
    this.consecutiveErrors = 0;
    this.patch({ queue: tracks, index: -1 });
    if (tracks.length === 0) {
      this.player?.pause();
      this.yt?.stop();
      return;
    }
    await this.loadIndex(Math.min(Math.max(startIndex, 0), tracks.length - 1), autoplay);
  }

  async playIndex(index: number) {
    this.consecutiveErrors = 0;
    await this.loadIndex(index, true);
  }

  async play() {
    await this.init();
    if (!this.hasSource) {
      if (this.state.queue.length > 0) await this.loadIndex(Math.max(this.state.index, 0), true);
      return;
    }
    if (this.isYT) {
      if (this.state.duration > 0 && this.state.position >= this.state.duration - 0.5) this.yt?.seekTo(0);
      this.yt?.play();
      return;
    }
    // Terminou a última faixa: recomeça do início
    if (this.state.duration > 0 && this.state.position >= this.state.duration - 0.5) {
      await this.player?.seekTo(0);
    }
    this.player?.play();
  }

  pause() {
    if (this.isYT) this.yt?.pause();
    this.player?.pause();
  }

  async toggle() {
    if (this.state.isPlaying) this.pause();
    else await this.play();
  }

  /** auto = true quando a faixa acabou sozinha (na última, para em vez de dar a volta) */
  async next(auto = false) {
    const { queue, index } = this.state;
    if (queue.length === 0) return;

    const isLast = index >= queue.length - 1;
    if (auto && isLast) {
      this.player?.pause();
      if (this.isYT) {
        this.yt?.pause();
        this.yt?.seekTo(0);
      } else {
        await this.player?.seekTo(0);
      }
      this.patch({ isPlaying: false, position: 0 });
      return;
    }
    await this.loadIndex(isLast ? 0 : index + 1, true);
  }

  async previous() {
    const { queue, index, position } = this.state;
    if (queue.length === 0) return;

    if (position > RESTART_THRESHOLD_SECONDS) {
      if (this.isYT) {
        this.yt?.seekTo(0);
        this.patch({ position: 0 });
      } else {
        await this.player?.seekTo(0);
      }
      return;
    }
    await this.loadIndex(index <= 0 ? queue.length - 1 : index - 1, true);
  }

  async seekTo(seconds: number) {
    if (!this.hasSource) return;
    const max = this.state.duration || seconds;
    const target = Math.min(Math.max(seconds, 0), max);
    this.patch({ position: target }); // atualiza a barra na hora
    if (this.isYT) {
      this.yt?.seekTo(target);
      return;
    }
    await this.player?.seekTo(target);
  }

  /** Libera o player (normalmente não precisa chamar; o app inteiro usa o mesmo) */
  dispose() {
    this.subscription?.remove();
    this.player?.clearLockScreenControls();
    this.player?.remove();
    this.player = null;
    this.subscription = null;
    this.initPromise = null;
    this.hasSource = false;
    this.lockScreenActive = false;
    this.state = INITIAL_STATE;
    this.listeners.forEach((l) => l());
  }
}

export const audioEngine = new AudioEngine();
