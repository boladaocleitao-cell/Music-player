import { AudioStatus, createAudioPlayer, setAudioModeAsync } from 'expo-audio';
import type { AudioPlayer } from 'expo-audio';
import { Track } from '../types/track';

export interface EngineState {
  queue: Track[];
  index: number;
  isPlaying: boolean;
  isBuffering: boolean;
  isLoaded: boolean;
  position: number; // segundos
  duration: number; // segundos
  error: string | null;
}

type Listener = () => void;

const INITIAL_STATE: EngineState = {
  queue: [],
  index: -1,
  isPlaying: false,
  isBuffering: false,
  isLoaded: false,
  position: 0,
  duration: 0,
  error: null,
};

// Se passou mais que isso, "voltar" reinicia a faixa em vez de ir para a anterior
const RESTART_THRESHOLD_SECONDS = 3;

class AudioEngine {
  private player: AudioPlayer | null = null;
  private subscription: { remove: () => void } | null = null;
  private initPromise: Promise<void> | null = null;
  private listeners = new Set<Listener>();
  private state: EngineState = INITIAL_STATE;

  private hasSource = false;
  private lockScreenActive = false;
  private finishHandled = false;
  private errorHandled = false;
  private consecutiveErrors = 0;

  // ---------- estado (compatível com useSyncExternalStore) ----------

  getState = (): EngineState => this.state;

  subscribe = (listener: Listener): (() => void) => {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  };

  private patch(partial: Partial<EngineState>) {
    this.state = { ...this.state, ...partial };
    this.listeners.forEach((l) => l());
  }

  // ---------- inicialização ----------

  init(): Promise<void> {
    if (!this.initPromise) {
      this.initPromise = (async () => {
        await setAudioModeAsync({
          playsInSilentMode: true,
          shouldPlayInBackground: true,
          // 'doNotMix' é obrigatório para os controles da tela de bloqueio
          interruptionMode: 'doNotMix',
        });
        // Um único player para o app todo: troca a fonte com replace()
        // e mantém a tela de bloqueio sempre ligada ao mesmo player.
        this.player = createAudioPlayer(null, { updateInterval: 500 });
        this.subscription = this.player.addListener('playbackStatusUpdate', this.onStatus);
      })();
    }
    return this.initPromise;
  }

  // ---------- eventos do player ----------

  private onStatus = (status: AudioStatus) => {
    const current = this.state.queue[this.state.index];

    this.patch({
      isPlaying: status.playing,
      isBuffering: status.isBuffering,
      isLoaded: status.isLoaded,
      position: status.currentTime,
      duration: status.duration > 0 ? status.duration : current?.duration ?? 0,
    });

    if (status.playing) this.consecutiveErrors = 0;

    if (status.error && !this.errorHandled) {
      this.errorHandled = true;
      this.handleError(String(status.error));
      return;
    }

    if (status.didJustFinish && !this.finishHandled) {
      this.finishHandled = true;
      void this.next(true);
    }
  };

  private handleError(message: string) {
    this.patch({ error: message, isPlaying: false });
    this.consecutiveErrors += 1;
    // Pula a faixa com problema, mas desiste se a fila inteira falhou em sequência
    if (this.consecutiveErrors < this.state.queue.length) {
      void this.next(true);
    }
  }

  // ---------- carregar e tocar ----------

  private async loadIndex(index: number, autoplay = true) {
    await this.init();
    const track = this.state.queue[index];
    const player = this.player;
    if (!track || !player) return;

    this.finishHandled = false;
    this.errorHandled = false;
    this.patch({
      index,
      position: 0,
      duration: track.duration ?? 0,
      isLoaded: false,
      error: null,
    });

    const source = typeof track.uri === 'number' ? track.uri : { uri: track.uri };
    player.replace(source);
    this.hasSource = true;
    if (autoplay) player.play();

    this.updateLockScreen(track);
  }

  private updateLockScreen(track: Track) {
    const player = this.player;
    if (!player) return;
    const metadata = {
      title: track.title,
      artist: track.artist,
      artworkUrl: track.artwork,
    };
    if (!this.lockScreenActive) {
      player.setActiveForLockScreen(true, metadata);
      this.lockScreenActive = true;
    } else {
      player.updateLockScreenMetadata(metadata);
    }
  }

  // ---------- API pública ----------

  /** Define a fila e começa a tocar em startIndex */
  async setQueue(tracks: Track[], startIndex = 0, autoplay = true) {
    this.consecutiveErrors = 0;
    this.patch({ queue: tracks, index: -1 });
    if (tracks.length === 0) {
      this.player?.pause();
      return;
    }
    await this.loadIndex(Math.min(Math.max(startIndex, 0), tracks.length - 1), autoplay);
  }

  async playIndex(index: number) {
    this.consecutiveErrors = 0;
    await this.loadIndex(index, true);
  }

  async play() {
    await this.init();
    if (!this.hasSource) {
      if (this.state.queue.length > 0) await this.loadIndex(Math.max(this.state.index, 0), true);
      return;
    }
    // Terminou a última faixa: recomeça do início
    if (this.state.duration > 0 && this.state.position >= this.state.duration - 0.5) {
      await this.player?.seekTo(0);
    }
    this.player?.play();
  }

  pause() {
    this.player?.pause();
  }

  async toggle() {
    if (this.state.isPlaying) this.pause();
    else await this.play();
  }

  /** auto = true quando a faixa acabou sozinha (na última, para em vez de dar a volta) */
  async next(auto = false) {
    const { queue, index } = this.state;
    if (queue.length === 0) return;

    const isLast = index >= queue.length - 1;
    if (auto && isLast) {
      this.player?.pause();
      await this.player?.seekTo(0);
      this.patch({ isPlaying: false, position: 0 });
      return;
    }
    await this.loadIndex(isLast ? 0 : index + 1, true);
  }

  async previous() {
    const { queue, index, position } = this.state;
    if (queue.length === 0) return;

    if (position > RESTART_THRESHOLD_SECONDS) {
      await this.player?.seekTo(0);
      return;
    }
    await this.loadIndex(index <= 0 ? queue.length - 1 : index - 1, true);
  }

  async seekTo(seconds: number) {
    if (!this.hasSource) return;
    const max = this.state.duration || seconds;
    const target = Math.min(Math.max(seconds, 0), max);
    this.patch({ position: target }); // atualiza a barra na hora
    await this.player?.seekTo(target);
  }

  /** Libera o player (normalmente não precisa chamar; o app inteiro usa o mesmo) */
  dispose() {
    this.subscription?.remove();
    this.player?.clearLockScreenControls();
    this.player?.remove();
    this.player = null;
    this.subscription = null;
    this.initPromise = null;
    this.hasSource = false;
    this.lockScreenActive = false;
    this.state = INITIAL_STATE;
    this.listeners.forEach((l) => l());
  }
}

export const audioEngine = new AudioEngine();
