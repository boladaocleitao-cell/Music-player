import AsyncStorage from '@react-native-async-storage/async-storage';
import { PRESETS } from '../data/presets';
import { Addon } from '../types/addon';

const ADDONS_KEY = 'music-player:addons';
const ACTIVE_KEY = 'music-player:active-addon';

export async function loadAddons(): Promise<{ addons: Addon[]; activeId: string | null }> {
  try {
    const raw = await AsyncStorage.getItem(ADDONS_KEY);
    const active = await AsyncStorage.getItem(ACTIVE_KEY);

    // primeiro uso: começa com os modelos prontos
    const addons: Addon[] = raw ? (JSON.parse(raw) as Addon[]) : PRESETS;
    const activeId = active && addons.some((a) => a.id === active) ? active : null;
    return { addons, activeId };
  } catch {
    return { addons: PRESETS, activeId: null };
  }
}

export async function saveAddons(addons: Addon[], activeId: string | null): Promise<void> {
  try {
    await AsyncStorage.setItem(ADDONS_KEY, JSON.stringify(addons));
    if (activeId) await AsyncStorage.setItem(ACTIVE_KEY, activeId);
    else await AsyncStorage.removeItem(ACTIVE_KEY);
  } catch {
    // sem persistência, o app continua funcionando
  }
}
