import { useEngineValue } from './usePlayer';

// Separado de usePlayer porque a posição muda a cada 500 ms.
// Assim só a barra de progresso re-renderiza, não a lista inteira.
export function useProgress() {
  const position = useEngineValue((s) => s.position);
  const duration = useEngineValue((s) => s.duration);
  return { position, duration };
}
