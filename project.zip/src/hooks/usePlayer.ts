import { useSyncExternalStore } from 'react';
import { audioEngine, EngineState } from '../services/audioEngine';

// Lê um pedaço do estado do engine. O selector deve devolver um valor
// primitivo ou uma referência estável (queue, por exemplo), senão entra em loop.
export function useEngineValue<T>(select: (state: EngineState) => T): T {
  return useSyncExternalStore(audioEngine.subscribe, () => select(audioEngine.getState()));
}

// Funções com ( ) => para o evento do onPress não ser repassado como argumento.
// Ex.: onPress={audioEngine.next} mandaria o evento como `auto`.
export const playerActions = {
  setQueue: (...args: Parameters<typeof audioEngine.setQueue>) => audioEngine.setQueue(...args),
  playIndex: (index: number) => audioEngine.playIndex(index),
  toggle: () => audioEngine.toggle(),
  pause: () => audioEngine.pause(),
  next: () => audioEngine.next(),
  previous: () => audioEngine.previous(),
  seekTo: (seconds: number) => audioEngine.seekTo(seconds),
  toggleShuffle: () => audioEngine.toggleShuffle(),
  cycleRepeat: () => audioEngine.cycleRepeat(),
};

export function usePlayer() {
  const queue = useEngineValue((s) => s.queue);
  const index = useEngineValue((s) => s.index);
  const isPlaying = useEngineValue((s) => s.isPlaying);
  const isBuffering = useEngineValue((s) => s.isBuffering);
  const error = useEngineValue((s) => s.error);
  const shuffle = useEngineValue((s) => s.shuffle);
  const repeat = useEngineValue((s) => s.repeat);

  const track = index >= 0 ? queue[index] ?? null : null;

  return { queue, index, track, isPlaying, isBuffering, error, shuffle, repeat, ...playerActions };
}
