import { Addon } from '../types/addon';

// Modelos prontos. O usuário só precisa preencher o "baseUrl".
export const PRESETS: Addon[] = [
  {
    id: 'jiosaavn',
    name: 'JioSaavn (API não oficial)',
    baseUrl: '',
    search: {
      url: '{baseUrl}/api/search/songs?query={query}&limit=20',
      listPath: 'data.results',
    },
    map: {
      id: 'id',
      title: 'name',
      artist: ['artists.primary[*].name', 'artists.all[*].name'],
      audio: ['downloadUrl[quality=160kbps].url', 'downloadUrl[-1].url'],
      artwork: 'image[-1].url',
      duration: 'duration',
    },
  },
  {
    id: 'lista-json',
    name: 'Lista JSON simples',
    baseUrl: '',
    list: { url: '{baseUrl}' },
    map: {
      id: ['id', '_id', 'uuid'],
      title: ['title', 'name', 'titulo', 'nome', 'track'],
      artist: ['artist', 'author', 'artista', 'autor', 'singer'],
      audio: ['url', 'uri', 'audio', 'audioUrl', 'src', 'stream', 'link', 'file', 'mp3'],
      artwork: ['artwork', 'image', 'cover', 'thumbnail', 'img', 'capa'],
      duration: ['duration', 'length'],
    },
  },
];

export const BLANK_ADDON: Addon = {
  id: 'minha-fonte',
  name: 'Minha fonte',
  baseUrl: 'https://',
  search: {
    url: '{baseUrl}/search?q={query}',
    listPath: 'results',
  },
  map: {
    title: 'title',
    artist: 'artist',
    audio: 'url',
    artwork: 'image',
  },
};
