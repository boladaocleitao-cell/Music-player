import { Track } from '../types/track';

export const INITIAL_TRACKS: Track[] = [
  {
    id: 'remote-1',
    title: 'SoundHelix Song 1',
    artist: 'SoundHelix',
    uri: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
    source: 'remote',
  },
  {
    id: 'remote-2',
    title: 'SoundHelix Song 2',
    artist: 'SoundHelix',
    uri: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3',
    source: 'remote',
  },
  {
    id: 'remote-3',
    title: 'SoundHelix Song 3',
    artist: 'SoundHelix',
    uri: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3',
    source: 'remote',
  },
];
