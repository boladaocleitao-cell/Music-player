import React, { useEffect } from 'react';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { PlayerScreen } from './src/screens/PlayerScreen';
import { useAppStore } from './src/store/appStore';
import { audioEngine } from './src/services/audioEngine';
import { resolveVideoId } from './src/services/resolver';

// Músicas do catálogo (home/álbuns) acham o vídeo no YouTube só quando você clica
audioEngine.setResolver((track) => resolveVideoId(useAppStore.getState().apiKey, track));

export default function App() {
  const hydrate = useAppStore((s) => s.hydrate);

  useEffect(() => {
    void hydrate();
    void audioEngine.init(); // prepara o modo de áudio antes do primeiro toque
  }, [hydrate]);

  return (
    <SafeAreaProvider>
      <StatusBar style="light" />
      <PlayerScreen />
    </SafeAreaProvider>
  );
}
